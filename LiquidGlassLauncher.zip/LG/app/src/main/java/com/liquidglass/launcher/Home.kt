@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.liquidglass.launcher

import android.app.ActivityOptions
import android.app.SearchManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Job
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class Actions(val launch: (AppInfo) -> Unit, val run: (Int) -> Unit, val info: (String) -> Unit,
              val uninstall: (String) -> Unit, val settings: (String?) -> Unit,
              val addWidget: (AppWidgetProviderInfo) -> Unit = {})

val LocalWidgetHost = staticCompositionLocalOf<AppWidgetHost?> { null }

class LauncherActivity : ComponentActivity() {
    private lateinit var prefs: Prefs
    private lateinit var model: HomeModel
    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private var pendingId = -1
    private var refreshJob: Job? = null
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_LOW -> prefs.batteryLow = true
                Intent.ACTION_BATTERY_OKAY -> prefs.batteryLow = false
                else -> { refreshJob?.cancel(); refreshJob = lifecycleScope.launch { kotlinx.coroutines.delay(400); model.refresh(applicationContext) } }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = Prefs(this); model = HomeModel(prefs)
        host = AppWidgetHost(this, 1024); awm = AppWidgetManager.getInstance(this)
        val pk = IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package") }
        ContextCompat.registerReceiver(this, rx, pk, ContextCompat.RECEIVER_EXPORTED)
        ContextCompat.registerReceiver(this, rx, IntentFilter().apply { addAction(Intent.ACTION_BATTERY_LOW); addAction(Intent.ACTION_BATTERY_OKAY) }, ContextCompat.RECEIVER_EXPORTED)
        val act = Actions(::launchApp, ::runAction,
            { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$it"))) },
            { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$it"))) },
            ::openSettings, ::addWidget)
        setContent { CompositionLocalProvider(LocalWidgetHost provides host) { Backdrop(prefs, model.shift) { HomeScreen(model, act) } } }
    }

    override fun onStart() { super.onStart(); try { host.startListening() } catch (e: Exception) { } }
    override fun onStop() { super.onStop(); try { host.stopListening() } catch (e: Exception) { } }

    // ---- Настоящие виджеты Android ----
    private fun addWidget(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId(); pendingId = id
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) { afterBind(id); return }
        val bind = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
        @Suppress("DEPRECATION") startActivityForResult(bind, REQ_BIND)
    }
    private fun afterBind(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) try { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) }
            catch (e: Exception) { commitWidget(id) }
        else commitWidget(id)
    }
    private fun commitWidget(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        val h = if (info != null) (info.minHeight / resources.displayMetrics.density).toInt().coerceIn(80, 360) else 120
        prefs.hosted = prefs.hosted + HostedWidget(id, h); pendingId = -1
    }
    private fun cancelWidget() { if (pendingId >= 0) host.deleteAppWidgetId(pendingId); pendingId = -1 }
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK && pendingId >= 0) afterBind(pendingId) else cancelWidget()
            REQ_CONFIG -> if (resultCode == RESULT_OK && pendingId >= 0) commitWidget(pendingId) else cancelWidget()
        }
    }
    private fun pruneWidgets() {
        val alive = prefs.hosted.filter { awm.getAppWidgetInfo(it.id) != null }
        if (alive.size != prefs.hosted.size) {
            prefs.hosted.filter { it !in alive }.forEach { host.deleteAppWidgetId(it.id) }; prefs.hosted = alive
        }
    }
    private companion object { const val REQ_BIND = 4101; const val REQ_CONFIG = 4102 }

    override fun onResume() {
        super.onResume(); prefs.reloadAll(); prefs.updateBattery(this); pruneWidgets()
        lifecycleScope.launch { model.refresh(applicationContext) }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); model.tick++ }
    override fun onDestroy() { super.onDestroy(); unregisterReceiver(rx) }

    private fun openSettings(screen: String?) = startActivity(Intent(this, SettingsActivity::class.java).putExtra("screen", screen))

    private fun launchApp(a: AppInfo) {
        model.bump(a.pkg)
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(a.pkg, a.cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val v = window.decorView
        val o = if (prefs.animApps) ActivityOptions.makeScaleUpAnimation(v, v.width / 2, v.height / 2, 1, 1).toBundle() else null
        try { startActivity(i, o) } catch (e: Exception) { Toast.makeText(this, "Не удалось открыть ${a.label}", Toast.LENGTH_SHORT).show() }
    }

    private fun runAction(a: Int) {
        when (a) {
            1 -> { model.search = false; model.drawer = true }
            2 -> notifications()
            3 -> { model.search = true; model.drawer = true }
            4 -> lock()
            5 -> openSettings(null)
            6 -> model.sheet = true
        }
    }
    private fun notifications() {
        try { Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(getSystemService("statusbar")) }
        catch (e: Exception) { LockService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }
    }
    private fun lock() {
        val ok = android.os.Build.VERSION.SDK_INT >= 28 &&
            LockService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) == true
        if (!ok) {
            Toast.makeText(this, "Включите службу «Liquid Glass Launcher» в специальных возможностях", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }
}

@Composable
fun rememberNow(): State<Date> = produceState(Date()) {
    while (true) { value = Date(); delay(60_000 - System.currentTimeMillis() % 60_000) }
}

@Composable
fun ClockWeather(modifier: Modifier) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    val now by rememberNow()
    val fmt = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    var w by remember { mutableStateOf<Weather?>(null) }
    var status by remember { mutableIntStateOf(0) } // 0 ок/загрузка, 1 нет разрешения, 2 ошибка сети/геолокации
    var retry by remember { mutableIntStateOf(0) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { retry++ }
    LaunchedEffect(retry, p.showWeather) {
        while (p.showWeather) {
            if (!hasLocationPermission(ctx)) { status = 1; break }
            val r = currentLocation(ctx)?.let { fetchWeather(ctx, it.first, it.second) }
            if (r != null) { w = r; status = 0; delay(30 * 60_000L) } else { status = 2; delay(2 * 60_000L) }
        }
    }
    Glass(modifier) {
        Row(Modifier.fillMaxSize().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(SimpleDateFormat(fmt, Locale.getDefault()).format(now), fontSize = 54.sp, fontWeight = FontWeight.Light)
                Text(SimpleDateFormat("EEE, d MMMM", Locale.getDefault()).format(now), fontSize = 15.sp)
            }
            if (p.showWeather) Column(Modifier.clickable { if (hasLocationPermission(ctx)) retry++ else perm.launch(android.Manifest.permission.ACCESS_COARSE_LOCATION) },
                horizontalAlignment = Alignment.End) {
                val ww = w
                if (ww != null) { Text("${weatherEmoji(ww.code)} ${ww.temp}°", fontSize = 28.sp); Text(ww.city, fontSize = 14.sp) }
                else when (status) {
                    1 -> { Text("🌡️ Погода", fontSize = 15.sp); Text("нажмите — разрешить", fontSize = 11.sp, modifier = Modifier.alpha(.7f)) }
                    2 -> { Text("🌡️ Нет данных", fontSize = 15.sp); Text("нажмите — повторить", fontSize = 11.sp, modifier = Modifier.alpha(.7f)) }
                    else -> Text("🌡️ …", fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(model: HomeModel, act: Actions) {
    val p = LocalPrefs.current
    val cols = p.cols
    BackHandler(model.drawer || model.folderId != null || model.sheet || model.menu != null || model.widgetPicker) {
        when { model.widgetPicker -> model.widgetPicker = false; model.menu != null -> model.menu = null; model.sheet -> model.sheet = false
            model.folderId != null -> model.folderId = null; else -> model.drawer = false }
    }
    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
        Column(Modifier.fillMaxSize()) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val cellW = (maxWidth - (p.padding * 2).dp) / cols
                val iconSz = (56.dp * p.iconScale).coerceAtMost(cellW - 4.dp)
                val labelH = if (p.hideLabels) 0.dp else 20.dp
                val cellH = (maxHeight / cols).coerceAtLeast(iconSz + labelH + p.gap.dp)
                val widgets = p.widgets
                val land = maxWidth > maxHeight // в ландшафте шапку (часы/виджеты/поиск) прячем — иконкам нужно место
                val headerH = if (land) 0.dp else (if (p.showClock) 158.dp else 0.dp) + widgets.fold(0.dp) { a, w -> a + widgetHeightDp(w.size).dp + 10.dp } +
                    p.hosted.fold(0.dp) { a, w -> a + w.h.dp + 10.dp } + (if (p.showSearch) 60.dp else 0.dp)
                val rows0 = ((maxHeight - headerH) / cellH).toInt().coerceAtLeast(0)
                val cap0 = cols * rows0; val capN = cols * cols
                model.cap0 = cap0; model.capN = capN
                val chunks = buildList { add(model.flat.take(cap0)); model.flat.drop(cap0).chunked(capN).forEach { add(it) } }
                val count = maxOf(p.pages, chunks.size)
                val pager = rememberPagerState { count }
                LaunchedEffect(pager, count) {
                    snapshotFlow { pager.currentPage + pager.currentPageOffsetFraction }.collect {
                        model.shift.value = if (count > 1) it / (count - 1) - 0.5f else 0f }
                }
                LaunchedEffect(model.tick) { if (model.tick > 0) { model.drawer = false; model.folderId = null; model.sheet = false; pager.animateScrollToPage(0) } }
                HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
                    Box(Modifier.graphicsLayer {
                        if (p.animPages) { val o = abs(pager.currentPage - page + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
                            scaleX = 1f - .08f * o; scaleY = scaleX; alpha = 1f - .45f * o }
                    }) {
                        Page(model, act, chunks.getOrElse(page) { emptyList() }, if (page == 0) 0 else cap0 + (page - 1) * capN,
                            page == 0 && !land, cellH, iconSz, headerH)
                    }
                }
                val dot = LocalContentColor.current
                Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp)) {
                    repeat(count) { Box(Modifier.padding(4.dp).size(if (it == pager.currentPage) 8.dp else 6.dp).clip(CircleShape)
                        .background(dot.copy(if (it == pager.currentPage) 1f else .45f))) }
                }
            }
            Dock(model, act)
        }
        if (model.drawer) AnimatedVisibility(true, enter = if (p.animApps) slideInVertically(tween(p.ms(320))) { it / 3 } + fadeIn(tween(p.ms(320))) else EnterTransition.None) { Drawer(model, act) }
        FolderOverlay(model, act)
        if (model.widgetPicker) WidgetPicker(model, act)
        model.menu?.let { MenuOverlay(it, model, act) }
        if (model.sheet) Overlay({ model.sheet = false }) {
            Glass(corner = 24.dp) { Column(Modifier.padding(8.dp).width(260.dp)) {
                MenuItem("Обои и стиль") { model.sheet = false; act.settings("wallpaper") }
                MenuItem("Добавить виджет Android") { model.sheet = false; model.widgetPicker = true }
                MenuItem("Фото-виджеты") { model.sheet = false; act.settings("photo") }
                MenuItem("Управление виджетами") { model.sheet = false; act.settings("widgets") }
                MenuItem("Настройки лаунчера") { model.sheet = false; act.settings(null) }
            } }
        }
    }
}

@Composable
fun HostedWidgetView(w: HostedWidget, modifier: Modifier = Modifier) {
    val host = LocalWidgetHost.current; val ctx = LocalContext.current
    val info = remember(w.id) { try { AppWidgetManager.getInstance(ctx).getAppWidgetInfo(w.id) } catch (e: Exception) { null } }
    if (host == null || info == null) return
    BoxWithConstraints(modifier.clip(RoundedCornerShape(22.dp))) {
        val wDp = maxWidth.value.toInt(); val hDp = maxHeight.value.toInt()
        AndroidView({ c -> host.createView(c, w.id, info) }, Modifier.fillMaxSize(),
            update = { v -> v.updateAppWidgetSize(Bundle(), wDp, hDp, wDp, hDp) })
    }
}

@Composable
fun WidgetPicker(model: HomeModel, act: Actions) {
    val ctx = LocalContext.current
    val list = remember {
        val pm = ctx.packageManager
        AppWidgetManager.getInstance(ctx).installedProviders.map { info ->
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString() } catch (e: Exception) { info.provider.packageName }
            Triple(info, info.loadLabel(pm), app)
        }.sortedWith(compareBy({ it.third.lowercase() }, { it.second.lowercase() }))
    }
    Overlay({ model.widgetPicker = false }) {
        Glass(Modifier.fillMaxWidth(.92f).heightIn(max = 520.dp), 28.dp) {
            Column {
                Text("Выберите виджет", Modifier.padding(16.dp), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                LazyColumn(Modifier.padding(horizontal = 8.dp)) {
                    items(list, key = { it.first.provider.flattenToString() }) { (info, title, app) ->
                        Column(Modifier.fillMaxWidth().clickable { model.widgetPicker = false; act.addWidget(info) }.padding(horizontal = 12.dp, vertical = 10.dp)) {
                            Text(title, fontSize = 15.sp); Text(app, fontSize = 12.sp, modifier = Modifier.alpha(.65f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AlphaIndex(letters: List<Char>, onPick: (Char) -> Unit, modifier: Modifier = Modifier) {
    var hh by remember { mutableIntStateOf(1) }
    fun pick(y: Float) { letters.getOrNull((y / hh * letters.size).toInt().coerceIn(0, letters.size - 1))?.let(onPick) }
    Column(modifier.onSizeChanged { hh = maxOf(1, it.height) }.pointerInput(letters) { detectTapGestures { pick(it.y) } }
        .pointerInput(letters) { detectVerticalDragGestures { c, _ -> pick(c.position.y) } }.padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        letters.forEach { Text(it.toString(), fontSize = 10.sp, modifier = Modifier.alpha(.8f).padding(horizontal = 4.dp)) }
    }
}
fun firstLetter(s: String): Char = s.trim().firstOrNull()?.uppercaseChar()?.let { if (it.isLetter()) it else '#' } ?: '#'

@Composable
fun Overlay(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(.4f)).pointerInput(Unit) { detectTapGestures { onDismiss() } }, Alignment.Center) {
        Box(Modifier.pointerInput(Unit) { detectTapGestures { } }) { content() }
    }
}
@Composable fun MenuItem(text: String, onClick: () -> Unit) =
    TextButton(onClick, Modifier.fillMaxWidth()) { Text(text, color = LocalContentColor.current, modifier = Modifier.fillMaxWidth()) }

@Composable
fun MenuOverlay(e: Entry, model: HomeModel, act: Actions) {
    val inDock = model.dock.any { it.id == e.id }
    val ctx = LocalContext.current
    val shortcuts = remember(e.id) { if (e.isFolder) emptyList() else loadShortcuts(ctx, e.pkgs[0]) }
    val idx = model.flat.indexOfFirst { it.id == e.id }
    Overlay({ model.menu = null }) {
        Glass(corner = 24.dp) { Column(Modifier.padding(8.dp).width(260.dp)) {
            shortcuts.take(4).forEach { s -> MenuItem("⚡ " + (s.shortLabel?.toString() ?: s.id)) { model.menu = null; startShortcut(ctx, s) } }
            if (idx >= 0) {
                val pg = model.pageOf(idx)
                MenuItem("На следующую страницу") { model.menu = null; model.moveToPage(idx, pg + 1) }
                if (pg > 0) MenuItem("На предыдущую страницу") { model.menu = null; model.moveToPage(idx, pg - 1) }
            }
            if (e.isFolder) {
                MenuItem("Открыть / переименовать") { model.menu = null; model.folderId = e.id }
                MenuItem("Расформировать папку") { model.menu = null; model.dissolve(e.id) }
            } else {
                val pkg = e.pkgs[0]
                if (inDock) MenuItem("Убрать из Dock") { model.menu = null; model.fromDock(e) }
                else MenuItem("Добавить в Dock") { model.menu = null; model.toDock(e) }
                MenuItem("Скрыть приложение") { model.menu = null; model.hide(pkg) }
                MenuItem("О приложении") { model.menu = null; act.info(pkg) }
                MenuItem("Удалить") { model.menu = null; act.uninstall(pkg) }
            }
        } }
    }
}

@Composable
fun FolderOverlay(model: HomeModel, act: Actions) {
    val p = LocalPrefs.current
    val e = model.flat.firstOrNull { it.id == model.folderId }
    AnimatedVisibility(e != null, enter = if (p.animFolder) scaleIn(tween(p.ms(280))) + fadeIn(tween(p.ms(280))) else EnterTransition.None,
        exit = if (p.animFolder) scaleOut(tween(p.ms(200))) + fadeOut(tween(p.ms(200))) else ExitTransition.None) {
        var last by remember { mutableStateOf(e) }; if (e != null) last = e
        val f = last
        if (f != null) Overlay({ model.folderId = null }) {
            Glass(Modifier.fillMaxWidth(.88f), 30.dp) { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                BasicTextField(f.name ?: "", { model.rename(f.id, it) }, singleLine = true,
                    textStyle = TextStyle(color = LocalContentColor.current, fontSize = 20.sp, fontWeight = FontWeight.Medium, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                    cursorBrush = SolidColor(LocalContentColor.current), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                val list = f.pkgs.mapNotNull { model.app(it) }
                LazyVerticalGrid(GridCells.Fixed(3), Modifier.heightIn(max = 380.dp)) {
                    items(list, key = { it.pkg }) { a ->
                        Column(Modifier.padding(6.dp).combinedClickable(onLongClick = { model.takeOut(f.id, a.pkg) }) { act.launch(a); model.folderId = null },
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            AppIconView(a, 56.dp * p.iconScale); Label(a.label, LocalContentColor.current)
                        }
                    }
                }
                Text("Долгое нажатие — достать из папки", fontSize = 11.sp, modifier = Modifier.alpha(.6f))
            } }
        }
    }
}

@Composable
fun Page(model: HomeModel, act: Actions, entries: List<Entry>, start: Int, header: Boolean, cellH: Dp, iconSz: Dp, headerH: Dp) {
    val p = LocalPrefs.current; val dens = LocalDensity.current; val scope = rememberCoroutineScope()
    val gs = rememberLazyGridState(); val cur by rememberUpdatedState(entries)
    var drag by remember { mutableStateOf<String?>(null) }
    var dp by remember { mutableStateOf(Offset.Zero) }
    var moved by remember { mutableFloatStateOf(0f) }
    var lock by remember { mutableStateOf(false) }
    fun hit(o: Offset) = gs.layoutInfo.visibleItemsInfo.firstOrNull { IntRect(it.offset, it.size).contains(o.round()) }
    fun release() { scope.launch { delay(400); lock = false } }

    Column(Modifier.fillMaxSize().padding(horizontal = p.padding.dp)
        .pointerInput(Unit) { detectTapGestures(onDoubleTap = { act.run(p.gDouble) }) }
        .pointerInput(Unit) {
            var acc = 0f
            detectVerticalDragGestures(onDragStart = { acc = 0f },
                onDragEnd = { if (acc < -120f) act.run(p.gUp) else if (acc > 120f) act.run(p.gDown) },
                onVerticalDrag = { _, d -> acc += d })
        }) {
        if (header) {
            val appear = remember { MutableTransitionState(!p.animWidgets).apply { targetState = true } }
            AnimatedVisibility(appear, enter = scaleIn(tween(p.ms(450), easing = FastOutSlowInEasing), .9f) + fadeIn(tween(p.ms(450)))) {
                Column(Modifier.height(headerH), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (p.showClock) ClockWeather(Modifier.fillMaxWidth().height(148.dp))
                    p.widgets.forEach { PhotoWidgetView(it, Modifier.fillMaxWidth().height(widgetHeightDp(it.size).dp)) }
                    p.hosted.forEach { HostedWidgetView(it, Modifier.fillMaxWidth().height(it.h.dp)) }
                    if (p.showSearch) Glass(Modifier.fillMaxWidth().height(50.dp).clickable { model.search = true; model.drawer = true }, 25.dp) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("G", color = Color(0xFF4285F4), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(14.dp)); Text("Поиск", Modifier.alpha(.65f), fontSize = 16.sp)
                        }
                    }
                }
            }
        }
        Box(Modifier.fillMaxSize()) {
            LazyVerticalGrid(GridCells.Fixed(p.cols), Modifier.fillMaxSize().pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { o ->
                        lock = true; dp = o; moved = 0f
                        val h = hit(o)
                        if (h == null) { drag = null; act.run(p.gLong) } else drag = h.key as String
                    },
                    onDrag = { c, d -> c.consume(); dp += d; moved += d.getDistance() },
                    onDragEnd = {
                        val k = drag; drag = null
                        val from = cur.indexOfFirst { it.id == k }
                        if (k != null && from >= 0) {
                            if (moved < 20f) model.menu = cur[from]
                            else hit(dp)?.let { t ->
                                if (t.key != k) {
                                    val to = cur.indexOfFirst { it.id == t.key }
                                    val c = Offset(t.offset.x + t.size.width / 2f, t.offset.y + t.size.height / 2f)
                                    if ((dp - c).getDistance() < t.size.height * .22f) model.merge(start + from, start + to)
                                    else model.move(start + from, start + to)
                                }
                            }
                        }
                        release()
                    },
                    onDragCancel = { drag = null; release() })
            }, state = gs, userScrollEnabled = false) {
                items(entries, key = { it.id }) { e ->
                    Column(Modifier.height(cellH).alpha(if (drag == e.id && moved > 20f) .25f else 1f).animateItem()
                        .clickable(remember { MutableInteractionSource() }, null) {
                            if (!lock) { if (e.isFolder) model.folderId = e.id else model.app(e.pkgs[0])?.let { act.launch(it) } }
                        }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        EntryIcon(e, model, iconSz)
                        if (!p.hideLabels) Label(if (e.isFolder) e.name ?: "" else model.app(e.pkgs[0])?.label ?: "")
                    }
                }
            }
            val d = drag; val de = entries.firstOrNull { it.id == d }
            if (de != null && moved > 20f) {
                val px = with(dens) { iconSz.toPx() }
                Box(Modifier.offset { IntOffset((dp.x - px / 2).roundToInt(), (dp.y - px / 2).roundToInt()) }.graphicsLayer { scaleX = 1.2f; scaleY = 1.2f }) {
                    EntryIcon(de, model, iconSz)
                }
            }
        }
    }
}

@Composable
fun Dock(model: HomeModel, act: Actions) {
    val p = LocalPrefs.current; val sz = 52.dp * p.dockScale
    var acc by remember { mutableFloatStateOf(0f) }
    Glass(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).pointerInput(Unit) {
        detectVerticalDragGestures(onDragStart = { acc = 0f }, onDragEnd = { if (acc < -80f) act.run(p.gDock) }, onVerticalDrag = { _, d -> acc += d })
    }, 34.dp) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            model.dock.forEach { e ->
                Box(Modifier.combinedClickable(onLongClick = { model.menu = e }) { model.app(e.pkgs[0])?.let { act.launch(it) } }) { EntryIcon(e, model, sz) }
            }
            IconTile(sz, Modifier.clickable { model.search = false; model.drawer = true }) {
                Icon(Icons.Rounded.Apps, "Все приложения", tint = LocalContentColor.current, modifier = Modifier.size(sz * .55f))
            }
        }
    }
}

@Composable
fun Drawer(model: HomeModel, act: Actions) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    val list = model.visible.filter { it.label.contains(q, true) }
    LaunchedEffect(Unit) { if (model.search) fr.requestFocus() }
    Glass(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
        .pointerInput(Unit) { var acc = 0f; detectVerticalDragGestures(onDragStart = { acc = 0f }, onDragEnd = { if (acc > 150f) model.drawer = false }, onVerticalDrag = { _, d -> acc += d }) }, 0.dp) {
        Column(Modifier.padding(16.dp)) {
            Glass(Modifier.fillMaxWidth().height(52.dp), 26.dp) {
                BasicTextField(q, { q = it }, singleLine = true, textStyle = TextStyle(color = LocalContentColor.current, fontSize = 16.sp),
                    cursorBrush = SolidColor(LocalContentColor.current), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        if (list.isNotEmpty()) { act.launch(list[0]); model.drawer = false }
                        else try { ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (e: Exception) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }), modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp).wrapContentHeight(Alignment.CenterVertically).focusRequester(fr),
                    decorationBox = { inner -> if (q.isEmpty()) Text("Поиск приложений и в интернете", Modifier.alpha(.6f)); inner() })
            }
            Spacer(Modifier.height(8.dp))
            val freq = remember { model.frequent() }
            val showFreq = q.isEmpty() && freq.isNotEmpty()
            val gs = rememberLazyGridState(); val scope = rememberCoroutineScope()
            val letters = remember(list) { list.map { firstLetter(it.label) }.distinct() }
            Box(Modifier.fillMaxSize()) {
                LazyVerticalGrid(GridCells.Fixed(p.cols), Modifier.fillMaxSize().padding(end = if (letters.size > 3 && q.isEmpty()) 16.dp else 0.dp), state = gs) {
                    if (showFreq) item(span = { GridItemSpan(maxLineSpan) }) {
                        Column(Modifier.padding(bottom = 6.dp)) {
                            Text("Часто используемые", fontSize = 12.sp, modifier = Modifier.alpha(.7f).padding(start = 6.dp, top = 4.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                freq.forEach { a ->
                                    Column(Modifier.padding(vertical = 8.dp).clickable { act.launch(a); model.drawer = false }, horizontalAlignment = Alignment.CenterHorizontally) {
                                        AppIconView(a, 56.dp * p.iconScale); if (!p.hideLabels) Label(a.label)
                                    }
                                }
                            }
                        }
                    }
                    items(list, key = { it.pkg }) { a ->
                        Column(Modifier.padding(vertical = 8.dp).combinedClickable(onLongClick = { model.menu = Entry(a.pkg, listOf(a.pkg)) }) { act.launch(a); model.drawer = false },
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            AppIconView(a, 56.dp * p.iconScale)
                            if (!p.hideLabels) Label(a.label, LocalContentColor.current)
                        }
                    }
                }
                if (letters.size > 3 && q.isEmpty()) AlphaIndex(letters, { ch ->
                    val idx = list.indexOfFirst { firstLetter(it.label) == ch }
                    if (idx >= 0) scope.launch { gs.scrollToItem(idx + if (showFreq) 1 else 0) }
                }, Modifier.align(Alignment.CenterEnd))
            }
        }
    }
}
