package com.liquidglass.launcher

import android.annotation.SuppressLint
import android.content.*
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.os.Build
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.*
import java.net.URL
import java.util.Locale
import java.util.UUID
import kotlin.reflect.KProperty

// ---------- Настройки (SharedPreferences + Compose state) ----------
class Pref<T : Any>(private val sp: SharedPreferences, private val key: String, private val def: T) {
    private val st = mutableStateOf(load())
    @Suppress("UNCHECKED_CAST")
    private fun load(): T = when (def) {
        is Boolean -> sp.getBoolean(key, def); is Int -> sp.getInt(key, def)
        is Float -> sp.getFloat(key, def); else -> sp.getString(key, def as String)
    } as T
    operator fun getValue(r: Any?, p: KProperty<*>): T = st.value
    operator fun setValue(r: Any?, p: KProperty<*>, v: T) {
        st.value = v
        sp.edit().apply {
            when (v) { is Boolean -> putBoolean(key, v); is Int -> putInt(key, v); is Float -> putFloat(key, v); else -> putString(key, v as String) }
        }.apply()
    }
    fun reload() { st.value = load() }
}

data class PhotoWidget(val id: String, val uris: List<String>, val size: Int = 1, val corner: Int = 24,
                       val alpha: Float = 1f, val slideshow: Boolean = true, val interval: Int = 8)
fun widgetHeightDp(size: Int) = when (size) { 0 -> 110; 1 -> 160; else -> 220 }
fun parseWidgets(s: String): List<PhotoWidget> = try {
    val a = JSONArray(s)
    List(a.length()) {
        val o = a.getJSONObject(it); val u = o.getJSONArray("u")
        PhotoWidget(o.getString("id"), List(u.length()) { i -> u.getString(i) }, o.getInt("s"), o.getInt("c"),
            o.getDouble("a").toFloat(), o.getBoolean("l"), o.getInt("t"))
    }
} catch (e: Exception) { emptyList() }
fun List<PhotoWidget>.toJson(): String = JSONArray(map {
    JSONObject().put("id", it.id).put("u", JSONArray(it.uris)).put("s", it.size).put("c", it.corner)
        .put("a", it.alpha.toDouble()).put("l", it.slideshow).put("t", it.interval)
}).toString()

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("lg", Context.MODE_PRIVATE)
    private val all = mutableListOf<Pref<*>>()
    private val defs = mutableMapOf<String, Any>()
    private fun <T : Any> p(k: String, d: T): Pref<T> { defs[k] = d; return Pref(sp, k, d).also { all += it } }

    var theme by p("theme", 0)                 // 0 система, 1 тёмная, 2 светлая
    var glass by p("glass", true); var glassAlpha by p("glassAlpha", 0.22f); var blur by p("blur", 18f)
    var shine by p("shine", 0.6f); var glow by p("glow", 0.4f); var glassColor by p("glassColor", 0); var corner by p("corner", 26f)
    var wp by p("wp", ""); var dim by p("dim", 0.25f); var bright by p("bright", 0f); var wpBlur by p("wpBlur", 0f)
    var parallax by p("parallax", true)
    var shape by p("shape", 2); var iconScale by p("iconScale", 1f); var gap by p("gap", 8f); var accent by p("accent", 0)
    var cols by p("cols", 4); var dockScale by p("dockScale", 1f); var hideLabels by p("hideLabels", false)
    var pages by p("pages", 3); var padding by p("padding", 12f); var hidden by p("hidden", "")
    var showClock by p("showClock", true); var showWeather by p("showWeather", true); var showSearch by p("showSearch", true)
    var gDouble by p("gDouble", 4); var gUp by p("gUp", 1); var gDown by p("gDown", 2)
    var gLong by p("gLong", 6); var gDock by p("gDock", 3)
    var animSpeed by p("animSpeed", 1f); var animApps by p("animApps", true); var animFolder by p("animFolder", true)
    var animPages by p("animPages", true); var animWidgets by p("animWidgets", true)
    var saverManual by p("saverManual", false); var autoSaver by p("autoSaver", true)
    var perf by p("perf", 0); var blurPanels by p("blurPanels", true)
    var layout by p("layout", ""); private var pw by p("pw", "")

    var batteryLow by mutableStateOf(false)
    private val wState = mutableStateOf(parseWidgets(pw))
    var widgets: List<PhotoWidget> get() = wState.value; set(v) { wState.value = v; pw = v.toJson() }

    val saver get() = saverManual || (autoSaver && batteryLow)
    val blurOn get() = glass && blurPanels && !saver && perf != 2 && Build.VERSION.SDK_INT >= 31
    val speed get() = if (saver) animSpeed * 2f else animSpeed
    fun ms(base: Int, on: Boolean = true) = if (on) (base / speed).toInt() else 0

    fun updateBattery(ctx: Context) {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val pct = i.getIntExtra("level", 100) * 100 / i.getIntExtra("scale", 100)
        batteryLow = pct <= 20 && i.getIntExtra("plugged", 0) == 0
    }
    fun reloadAll() { all.forEach { it.reload() }; wState.value = parseWidgets(pw) }
    fun export(): String = JSONObject(sp.all.filterKeys { it in defs }).toString()
    fun import(json: String) {
        val o = JSONObject(json)
        sp.edit().apply {
            defs.forEach { (k, d) -> if (o.has(k)) when (d) {
                is Boolean -> putBoolean(k, o.getBoolean(k)); is Int -> putInt(k, o.getInt(k))
                is Float -> putFloat(k, o.getDouble(k).toFloat()); else -> putString(k, o.getString(k))
            } }
        }.apply(); reloadAll()
    }
    fun reset() { sp.edit().clear().apply(); reloadAll() }
}

// ---------- Приложения ----------
data class AppInfo(val pkg: String, val cls: String, val label: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map {
        AppInfo(it.activityInfo.packageName, it.activityInfo.name, it.loadLabel(pm).toString(),
            it.loadIcon(pm).toBitmap(144, 144).asImageBitmap())
    }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
}

data class Entry(val id: String, val pkgs: List<String>, val name: String? = null) {
    val isFolder get() = name != null
}
private fun ser(l: List<Entry>) = JSONArray(l.map {
    JSONObject().put("i", it.id).put("n", it.name ?: JSONObject.NULL).put("p", JSONArray(it.pkgs))
})
private fun par(a: JSONArray?): List<Entry> = List(a?.length() ?: 0) {
    val o = a!!.getJSONObject(it); val p = o.getJSONArray("p")
    Entry(o.getString("i"), List(p.length()) { i -> p.getString(i) }, if (o.isNull("n")) null else o.getString("n"))
}

class HomeModel(val prefs: Prefs) {
    var apps by mutableStateOf(emptyList<AppInfo>())
    var flat by mutableStateOf(emptyList<Entry>())
    var dock by mutableStateOf(emptyList<Entry>())
    var tick by mutableIntStateOf(0)
    var drawer by mutableStateOf(false); var search by mutableStateOf(false)
    var sheet by mutableStateOf(false); var menu by mutableStateOf<Entry?>(null)
    var folderId by mutableStateOf<String?>(null)
    val shift = mutableStateOf(0f)

    val hiddenSet get() = prefs.hidden.split(",").filter { it.isNotEmpty() }.toSet()
    val visible get() = apps.filter { it.pkg !in hiddenSet }
    fun app(pkg: String) = apps.firstOrNull { it.pkg == pkg }

    suspend fun refresh(ctx: Context) {
        val list = withContext(Dispatchers.Default) { loadApps(ctx) }
        apps = list
        val valid = list.map { it.pkg }.toSet() - hiddenSet
        var (f, d) = try { JSONObject(prefs.layout).let { par(it.optJSONArray("flat")) to par(it.optJSONArray("dock")) } }
                     catch (e: Exception) { emptyList<Entry>() to emptyList() }
        if (prefs.layout.isEmpty()) d = defaultDock(ctx, valid)
        fun clean(l: List<Entry>) = l.mapNotNull { e ->
            val p = e.pkgs.filter { it in valid }
            when { p.isEmpty() -> null; e.isFolder && p.size > 1 -> e.copy(pkgs = p); else -> Entry(p[0], listOf(p[0])) }
        }
        f = clean(f); d = clean(d)
        val placed = (f + d).flatMap { it.pkgs }.toSet()
        flat = f + list.filter { it.pkg in valid && it.pkg !in placed }.map { Entry(it.pkg, listOf(it.pkg)) }
        dock = d; save()
    }
    private fun defaultDock(ctx: Context, valid: Set<String>): List<Entry> {
        val pm = ctx.packageManager
        val intents = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS), Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER))
        return intents.mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { it in valid }.distinct().map { Entry(it, listOf(it)) }
    }
    fun save() { prefs.layout = JSONObject().put("flat", ser(flat)).put("dock", ser(dock)).toString() }
    fun move(from: Int, to: Int) {
        if (from == to || from !in flat.indices) return
        val m = flat.toMutableList(); val e = m.removeAt(from); m.add(to.coerceIn(0, m.size), e); flat = m; save()
    }
    fun merge(from: Int, to: Int) {
        val a = flat[from]; val b = flat[to]
        if (a.isFolder) { move(from, to); return }
        val m = flat.toMutableList()
        m[to] = if (b.isFolder) b.copy(pkgs = b.pkgs + a.pkgs) else Entry(UUID.randomUUID().toString(), b.pkgs + a.pkgs, "Папка")
        m.removeAt(from); flat = m; save()
    }
    fun rename(id: String, n: String) { flat = flat.map { if (it.id == id) it.copy(name = n) else it }; save() }
    fun takeOut(id: String, pkg: String) {
        val m = mutableListOf<Entry>()
        flat.forEach { e ->
            if (e.id == id) {
                val left = e.pkgs - pkg
                if (left.size > 1) m += e.copy(pkgs = left) else if (left.size == 1) m += Entry(left[0], left)
                m += Entry(pkg, listOf(pkg))
            } else m += e
        }
        flat = m; if (flat.none { it.id == folderId }) folderId = null; save()
    }
    fun dissolve(id: String) {
        flat = flat.flatMap { if (it.id == id) it.pkgs.map { p -> Entry(p, listOf(p)) } else listOf(it) }; save()
    }
    fun toDock(e: Entry) { if (dock.size < 4 && !e.isFolder) { flat = flat - e; dock = dock + e; save() } }
    fun fromDock(e: Entry) { dock = dock - e; flat = flat + e; save() }
    fun hide(pkg: String) {
        prefs.hidden = (hiddenSet + pkg).joinToString(","); flat = flat.mapNotNull { e ->
            val p = e.pkgs - pkg; if (p.isEmpty()) null else e.copy(pkgs = p) }; dock = dock.filter { it.pkgs[0] != pkg }; save()
    }
}

// ---------- Погода (Open-Meteo, координаты — только после разрешения) ----------
data class Weather(val temp: Int, val code: Int, val city: String)
fun weatherEmoji(c: Int) = when (c) { 0 -> "☀️"; 1, 2 -> "🌤️"; 3 -> "☁️"; 45, 48 -> "🌫️"; in 51..67, in 80..82 -> "🌧️"; in 71..77, 85, 86 -> "❄️"; in 95..99 -> "⛈️"; else -> "⛅" }

@SuppressLint("MissingPermission")
fun lastLocation(ctx: Context): Pair<Double, Double>? {
    if (ctx.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
    val lm = ctx.getSystemService(LocationManager::class.java)
    return lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }?.let { it.latitude to it.longitude }
}
suspend fun fetchWeather(ctx: Context, lat: Double, lon: Double): Weather? = withContext(Dispatchers.IO) {
    try {
        val j = JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code").readText()).getJSONObject("current")
        @Suppress("DEPRECATION")
        val city = try { Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()?.locality ?: "" } catch (e: Exception) { "" }
        Weather(Math.round(j.getDouble("temperature_2m")).toInt(), j.getInt("weather_code"), city)
    } catch (e: Exception) { null }
}
