package com.liquidglass.launcher

import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.RuntimeShader
import android.net.Uri
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

val LocalPrefs = staticCompositionLocalOf<Prefs> { error("Prefs") }
val LocalScreen = compositionLocalOf { IntSize(1080, 1920) }
val LocalParallax = compositionLocalOf<State<Float>> { mutableStateOf(0f) }
val LocalDark = compositionLocalOf { true }
/** В настройках десятки панелей — там блюр под каждой строкой отключаем ради плавности. */
val LocalGlassBlur = compositionLocalOf { true }
val Palette = listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6), Color(0xFF22D3EE), Color(0xFF22C55E), Color(0xFFEAB308),
    Color(0xFFF97316), Color(0xFFEF4444), Color(0xFFEC4899), Color(0xFF6B7280))
val PaletteNames = listOf("Фиолетовый", "Синий", "Бирюзовый", "Зелёный", "Жёлтый", "Оранжевый", "Красный", "Розовый", "Графит", "Свой")

@Composable
fun Backdrop(prefs: Prefs, shift: State<Float>, content: @Composable BoxScope.() -> Unit) {
    val dark = when (prefs.theme) { 1 -> true; 2 -> false; else -> isSystemInDarkTheme() }
    val accent = prefs.color(prefs.accent)
    val onAcc = if (accent.luminance() > .55f) Color.Black else Color.White
    val cs = if (dark) darkColorScheme(primary = accent, onPrimary = onAcc, secondaryContainer = accent.copy(.45f), onSecondaryContainer = Color.White,
        surface = Color(0xFF1B1030), onSurface = Color.White)
    else lightColorScheme(primary = accent, onPrimary = onAcc, secondaryContainer = accent.copy(.3f), onSecondaryContainer = Color(0xFF1A1033),
        surface = Color(0xFFF4EEFF), onSurface = Color(0xFF1A1033))
    var size by remember { mutableStateOf(IntSize(1080, 1920)) }
    val act = LocalContext.current as? ComponentActivity
    DisposableEffect(dark) {
        val st = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
        act?.enableEdgeToEdge(st, st)
        onDispose { }
    }
    CompositionLocalProvider(LocalPrefs provides prefs, LocalScreen provides size, LocalParallax provides shift, LocalDark provides dark,
        LocalContentColor provides cs.onSurface) {
        MaterialTheme(cs) {
            Box(Modifier.fillMaxSize().onSizeChanged { size = it }) {
                if (prefs.sysWp) { if (prefs.dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(prefs.dim))) }
                else WallpaperLayer(prefs.wp, prefs.dim, prefs.bright, prefs.wpBlur, Modifier.fillMaxSize(), prefs.parallax && !prefs.saver)
                if (!dark) Box(Modifier.fillMaxSize().background(Color.White.copy(.45f)))
                content()
            }
        }
    }
}

@Composable
fun WallpaperLayer(uri: String, dim: Float, bright: Float, blur: Float, modifier: Modifier = Modifier, parallax: Boolean = true) {
    val shift = LocalParallax.current
    val pr = LocalPrefs.current; val ac = pr.color(pr.accent)
    Box(modifier.clipToBounds()) {
        val m = Modifier.fillMaxSize().graphicsLayer {
            if (parallax) { scaleX = 1.12f; scaleY = 1.12f; translationX = -shift.value * size.width * 0.1f }
        }.let { if (blur > 0.5f) it.blur(blur.dp, BlurredEdgeTreatment.Unbounded) else it }
        if (uri.isEmpty()) Box(m.background(Brush.verticalGradient(listOf(lerp(ac, Color.Black, .5f), lerp(ac, Color.Black, .8f), Color(0xFF04040F)))))
        else AsyncImage(Uri.parse(uri), null, m, contentScale = ContentScale.Crop)
        if (dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(dim)))
        if (bright > 0f) Box(Modifier.fillMaxSize().background(Color.White.copy(bright)))
    }
}

/** Liquid Glass панель: размытая копия обоев под панелью + тонировка + блик + свечение + светящаяся кромка. */
@Composable
fun Glass(modifier: Modifier = Modifier, corner: Dp? = null, content: @Composable BoxScope.() -> Unit) {
    val p = LocalPrefs.current; val dark = LocalDark.current
    val shape = RoundedCornerShape(corner ?: p.corner.dp)
    if (!p.glass) {
        Box(modifier.clip(shape).background(if (dark) Color(0xFF1B1030) else Color(0xFFF1EAFF)).border(1.dp, Color.White.copy(.12f), shape), content = content)
        return
    }
    val tint = p.color(p.glassColor); val a = p.glassAlpha
    val scr = LocalScreen.current; val d = LocalDensity.current
    var pos by remember { mutableStateOf(IntOffset.Zero) }
    Box(modifier.onGloballyPositioned { pos = it.positionInRoot().round() }
        .shadow((p.glow * 18f).dp, shape, ambientColor = tint, spotColor = tint)
        .clip(shape)
        .border(1.2.dp, Brush.linearGradient(listOf(Color.White.copy(.65f * p.shine), tint.copy(.2f), Color.White.copy(.3f * p.shine))), shape)) {
        if (p.blurOn && LocalGlassBlur.current) {
            val cornerPx = with(d) { (corner ?: p.corner.dp).toPx() }
            val lens = p.refract && Build.VERSION.SDK_INT >= 33
            Box(Modifier.matchParentSize().then(if (lens) Modifier.refraction(cornerPx, 14f * (0.5f + p.shine)) else Modifier)) {
                Box(Modifier.matchParentSize().wrapContentSize(Alignment.TopStart, unbounded = true)
                    .offset { IntOffset(-pos.x, -pos.y) }
                    .size(with(d) { scr.width.toDp() }, with(d) { scr.height.toDp() })
                    .blur(p.blur.dp, BlurredEdgeTreatment.Unbounded)) {
                    WallpaperLayer(p.wp, p.dim, p.bright, p.wpBlur, Modifier.fillMaxSize(), p.parallax && !p.saver)
                }
            }
        }
        Box(Modifier.matchParentSize().background(Brush.linearGradient(listOf(Color.White.copy(a * .6f), tint.copy(a * 1.2f), tint.copy(a * .8f)))))
        if (p.shine > 0f) Box(Modifier.matchParentSize().background(Brush.linearGradient(
            colorStops = arrayOf(0f to Color.White.copy(.32f * p.shine), .4f to Color.Transparent, 1f to Color.White.copy(.07f * p.shine)))))
        content()
    }
}

private const val LENS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float r;
uniform float k;
half4 main(float2 c) {
    float2 p = c - size * 0.5;
    float2 q = abs(p) - (size * 0.5 - float2(r));
    float d = length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;
    float t = clamp(-d / 26.0, 0.0, 1.0);
    float bend = pow(1.0 - t, 2.5) * k;
    float2 dir = p / max(length(p), 0.001);
    float2 o = dir * bend;
    half4 base = content.eval(c - o);
    half red = content.eval(c - o * 1.12).r;
    half blue = content.eval(c - o * 0.88).b;
    return half4(red, base.g, blue, base.a);
}
"""

/** «Линза»: у кромки панели размытый фон преломляется (Android 13+). При любой ошибке шейдера эффект просто не применяется. */
fun Modifier.refraction(cornerPx: Float, strength: Float): Modifier = composed {
    val shader = remember { try { RuntimeShader(LENS_AGSL) } catch (e: Throwable) { null } }
    if (shader == null) this else graphicsLayer {
        try {
            shader.setFloatUniform("size", size.width, size.height)
            shader.setFloatUniform("r", cornerPx.coerceAtMost(minOf(size.width, size.height) / 2f))
            shader.setFloatUniform("k", strength)
            renderEffect = AndroidRenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
        } catch (e: Throwable) { }
    }
}

@Composable
fun IconTile(size: Dp, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val p = LocalPrefs.current; val acc = p.color(p.accent)
    val shape: Shape = when (p.shape) { 0 -> CircleShape; 1 -> RoundedCornerShape(size * 0.08f); else -> RoundedCornerShape(size * 0.28f) }
    val bg = if (p.shape == 3 && p.glass) Brush.linearGradient(listOf(Color.White.copy(.38f), acc.copy(.22f)))
             else Brush.linearGradient(listOf(acc.copy(.4f), Color.Black.copy(.3f)))
    Box(modifier.size(size).clip(shape).background(bg)
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.55f), Color.Transparent, Color.White.copy(.2f))), shape),
        contentAlignment = Alignment.Center, content = content)
}

@Composable
fun AppIconView(app: AppInfo, size: Dp) {
    val p = LocalPrefs.current
    val mono = if (p.themed) app.mono else null
    Box {
        IconTile(size) {
            when {
                app.placeholder -> Text(app.label.take(1).uppercase(), color = Color.White.copy(.85f),
                    fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.SemiBold)
                mono != null -> Image(mono, app.label, Modifier.fillMaxSize().padding(size * 0.1f), colorFilter = ColorFilter.tint(Color.White))
                app.adaptive -> Image(app.icon, app.label, Modifier.fillMaxSize())
                else -> Image(app.icon, app.label, Modifier.fillMaxSize().padding(size * 0.13f))
            }
        }
        if (p.badges) CountBadge(Badges.of(app.pkg), Modifier.align(Alignment.TopEnd))
    }
}

@Composable
fun CountBadge(n: Int, modifier: Modifier = Modifier) {
    if (n <= 0) return
    Box(modifier.semantics { contentDescription = "Уведомлений: $n" }.offset(3.dp, (-3).dp).defaultMinSize(18.dp, 18.dp).clip(CircleShape).background(Color(0xFFEF4444))
        .border(1.dp, Color.White.copy(.8f), CircleShape), contentAlignment = Alignment.Center) {
        Text(if (n > 99) "99+" else n.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
fun EntryIcon(e: Entry, model: HomeModel, size: Dp) {
    val p = LocalPrefs.current
    if (e.isFolder) Box {
        IconTile(size) {
            Column(Modifier.padding(size * 0.14f)) {
                e.pkgs.take(4).chunked(2).forEach { row ->
                    Row(Modifier.weight(1f)) { row.forEach { pk -> model.app(pk)?.let { Image(it.icon, it.label, Modifier.weight(1f).fillMaxHeight().padding(1.dp)) } } }
                }
            }
        }
        if (p.badges) CountBadge(e.pkgs.sumOf { Badges.of(it) }, Modifier.align(Alignment.TopEnd))
    } else model.app(e.pkgs[0])?.let { AppIconView(it, size) } ?: IconTile(size) { }
}

@Composable
fun Label(text: String, color: Color = Color.Unspecified) =
    Text(text, color = if (color == Color.Unspecified) LocalContentColor.current else color, fontSize = 11.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        style = LocalTextStyle.current.copy(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(.6f), blurRadius = 6f)))

@Composable
fun PhotoWidgetView(w: PhotoWidget, modifier: Modifier = Modifier) {
    val p = LocalPrefs.current
    var i by remember(w.uris) { mutableIntStateOf(0) }
    LaunchedEffect(w.uris, w.slideshow, w.interval, p.saver) {
        if (w.slideshow && w.uris.size > 1) while (true) { delay(w.interval * (if (p.saver) 3 else 1) * 1000L); i = (i + 1) % w.uris.size }
    }
    Box(modifier.alpha(w.alpha).clip(RoundedCornerShape(w.corner.dp)).background(Color.Black.copy(.3f))
        .border(1.dp, Color.White.copy(.35f), RoundedCornerShape(w.corner.dp))) {
        if (w.uris.isEmpty()) Text("Нет фото", Modifier.align(Alignment.Center), color = Color.White)
        else Crossfade(i.coerceAtMost(w.uris.size - 1), animationSpec = tween(p.ms(700))) {
            AsyncImage(Uri.parse(w.uris[it]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}
