package com.liquidglass.launcher

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

val LocalPrefs = staticCompositionLocalOf<Prefs> { error("Prefs") }
val LocalScreen = compositionLocalOf { IntSize(1080, 1920) }
val LocalParallax = compositionLocalOf<State<Float>> { mutableStateOf(0f) }
val LocalDark = compositionLocalOf { true }
val Palette = listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6), Color(0xFF374151), Color(0xFFEC4899), Color(0xFF22D3EE))
val PaletteNames = listOf("Фиолетовый", "Синий", "Графит", "Розовый", "Бирюзовый")

@Composable
fun Backdrop(prefs: Prefs, shift: State<Float>, content: @Composable BoxScope.() -> Unit) {
    val dark = when (prefs.theme) { 1 -> true; 2 -> false; else -> isSystemInDarkTheme() }
    val accent = Palette[prefs.accent]
    val cs = if (dark) darkColorScheme(primary = accent, secondaryContainer = accent.copy(.45f), onSecondaryContainer = Color.White,
        surface = Color(0xFF1B1030), onSurface = Color.White)
    else lightColorScheme(primary = accent, secondaryContainer = accent.copy(.3f), onSecondaryContainer = Color(0xFF1A1033),
        surface = Color(0xFFF4EEFF), onSurface = Color(0xFF1A1033))
    var size by remember { mutableStateOf(IntSize(1080, 1920)) }
    CompositionLocalProvider(LocalPrefs provides prefs, LocalScreen provides size, LocalParallax provides shift, LocalDark provides dark,
        LocalContentColor provides cs.onSurface) {
        MaterialTheme(cs) {
            Box(Modifier.fillMaxSize().onSizeChanged { size = it }) {
                WallpaperLayer(prefs.wp, prefs.dim, prefs.bright, prefs.wpBlur, Modifier.fillMaxSize(), prefs.parallax && !prefs.saver)
                if (!dark) Box(Modifier.fillMaxSize().background(Color.White.copy(.45f)))
                content()
            }
        }
    }
}

@Composable
fun WallpaperLayer(uri: String, dim: Float, bright: Float, blur: Float, modifier: Modifier = Modifier, parallax: Boolean = true) {
    val shift = LocalParallax.current
    Box(modifier.clipToBounds()) {
        val m = Modifier.fillMaxSize().graphicsLayer {
            if (parallax) { scaleX = 1.12f; scaleY = 1.12f; translationX = -shift.value * size.width * 0.1f }
        }.let { if (blur > 0.5f) it.blur(blur.dp, BlurredEdgeTreatment.Unbounded) else it }
        if (uri.isEmpty()) Box(m.background(Brush.verticalGradient(listOf(Color(0xFF3A0F7A), Color(0xFF160A3F), Color(0xFF04040F)))))
        else AsyncImage(Uri.parse(uri), null, m, contentScale = ContentScale.Crop)
        if (dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(dim)))
        if (bright > 0f) Box(Modifier.fillMaxSize().background(Color.White.copy(bright)))
    }
}

/** Liquid Glass панель: размытая копия обоев под панелью + тонировка + блик + свечение + светящаяся кромка. */
@Composable
fun Glass(modifier: Modifier = Modifier, corner: Dp? = null, content: @Composable BoxScope.() -> Unit) {
    val p = LocalPrefs.current; val dark = LocalDark.current
    val shape = RoundedCornerShape(corner ?: p.corner.dp)
    if (!p.glass) {
        Box(modifier.clip(shape).background(if (dark) Color(0xFF1B1030) else Color(0xFFF1EAFF)).border(1.dp, Color.White.copy(.12f), shape), content = content)
        return
    }
    val tint = Palette[p.glassColor]; val a = p.glassAlpha
    val scr = LocalScreen.current; val d = LocalDensity.current
    var pos by remember { mutableStateOf(IntOffset.Zero) }
    Box(modifier.onGloballyPositioned { pos = it.positionInRoot().round() }
        .shadow((p.glow * 18f).dp, shape, ambientColor = tint, spotColor = tint)
        .clip(shape)
        .border(1.2.dp, Brush.linearGradient(listOf(Color.White.copy(.65f * p.shine), tint.copy(.2f), Color.White.copy(.3f * p.shine))), shape)) {
        if (p.blurOn) {
            Box(Modifier.matchParentSize().wrapContentSize(Alignment.TopStart, unbounded = true)
                .offset { IntOffset(-pos.x, -pos.y) }
                .size(with(d) { scr.width.toDp() }, with(d) { scr.height.toDp() })
                .blur(p.blur.dp, BlurredEdgeTreatment.Unbounded)) {
                WallpaperLayer(p.wp, p.dim, p.bright, p.wpBlur, Modifier.fillMaxSize(), p.parallax && !p.saver)
            }
        }
        Box(Modifier.matchParentSize().background(Brush.linearGradient(listOf(Color.White.copy(a * .6f), tint.copy(a * 1.2f), tint.copy(a * .8f)))))
        if (p.shine > 0f) Box(Modifier.matchParentSize().background(Brush.linearGradient(
            colorStops = arrayOf(0f to Color.White.copy(.32f * p.shine), .4f to Color.Transparent, 1f to Color.White.copy(.07f * p.shine)))))
        content()
    }
}

@Composable
fun IconTile(size: Dp, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val p = LocalPrefs.current; val acc = Palette[p.accent]
    val shape: Shape = when (p.shape) { 0 -> CircleShape; 1 -> RoundedCornerShape(size * 0.08f); else -> RoundedCornerShape(size * 0.28f) }
    val bg = if (p.shape == 3 && p.glass) Brush.linearGradient(listOf(Color.White.copy(.38f), acc.copy(.22f)))
             else Brush.linearGradient(listOf(acc.copy(.4f), Color.Black.copy(.3f)))
    Box(modifier.size(size).clip(shape).background(bg)
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.55f), Color.Transparent, Color.White.copy(.2f))), shape),
        contentAlignment = Alignment.Center, content = content)
}

@Composable
fun AppIconView(app: AppInfo, size: Dp) = IconTile(size) { Image(app.icon, null, Modifier.fillMaxSize().padding(size * 0.13f)) }

@Composable
fun EntryIcon(e: Entry, model: HomeModel, size: Dp) {
    if (e.isFolder) IconTile(size) {
        Column(Modifier.padding(size * 0.14f)) {
            e.pkgs.take(4).chunked(2).forEach { row ->
                Row(Modifier.weight(1f)) { row.forEach { pk -> model.app(pk)?.let { Image(it.icon, null, Modifier.weight(1f).fillMaxHeight().padding(1.dp)) } } }
            }
        }
    } else model.app(e.pkgs[0])?.let { AppIconView(it, size) }
}

@Composable
fun Label(text: String, color: Color = Color.White) =
    Text(text, color = color, fontSize = 11.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        style = LocalTextStyle.current.copy(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(.6f), blurRadius = 6f)))

@Composable
fun PhotoWidgetView(w: PhotoWidget, modifier: Modifier = Modifier) {
    val p = LocalPrefs.current
    var i by remember(w.uris) { mutableIntStateOf(0) }
    LaunchedEffect(w.uris, w.slideshow, w.interval, p.saver) {
        if (w.slideshow && w.uris.size > 1) while (true) { delay(w.interval * (if (p.saver) 3 else 1) * 1000L); i = (i + 1) % w.uris.size }
    }
    Box(modifier.alpha(w.alpha).clip(RoundedCornerShape(w.corner.dp)).background(Color.Black.copy(.3f))
        .border(1.dp, Color.White.copy(.35f), RoundedCornerShape(w.corner.dp))) {
        if (w.uris.isEmpty()) Text("Нет фото", Modifier.align(Alignment.Center), color = Color.White)
        else Crossfade(i.coerceAtMost(w.uris.size - 1), animationSpec = tween(p.ms(700))) {
            AsyncImage(Uri.parse(w.uris[it]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}
