package com.liquidglass.launcher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.mutableStateMapOf

/** Счётчики уведомлений по пакетам для бейджей на иконках. Данные только в памяти, никуда не отправляются. */
object Badges {
    val counts = mutableStateMapOf<String, Int>()
    fun of(pkg: String) = counts[pkg] ?: 0
}

class NotifService : NotificationListenerService() {
    override fun onListenerConnected() = recount()
    override fun onNotificationPosted(sbn: StatusBarNotification?) = recount()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = recount()
    override fun onListenerDisconnected() { Badges.counts.clear() }

    private fun recount() {
        val list = try { activeNotifications } catch (e: Exception) { null } ?: return
        val m = HashMap<String, Int>()
        list.filter { !it.isOngoing && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .forEach { m[it.packageName] = (m[it.packageName] ?: 0) + 1 }
        Badges.counts.keys.toList().filter { it !in m }.forEach { Badges.counts.remove(it) }
        m.forEach { (k, v) -> if (Badges.counts[k] != v) Badges.counts[k] = v }
    }
}
