package com.liquidglass.launcher

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.*
import android.media.AudioManager
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch
import java.util.UUID

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = Prefs(this); prefs.updateBattery(this)
        val start = intent.getStringExtra("screen")
        setContent { Backdrop(prefs, remember { mutableStateOf(0f) }) { SettingsRoot(start) } }
    }
}

// ---------- Базовые элементы ----------
@Composable
fun GRow(title: String, sub: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Glass(Modifier.fillMaxWidth().let { if (onClick != null) it.clickable { onClick() } else it }, 22.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                if (sub != null) Text(sub, fontSize = 12.sp, modifier = Modifier.alpha(.7f))
            }
            trailing()
        }
    }
}

@Composable fun Toggle(title: String, sub: String? = null, v: Boolean, on: (Boolean) -> Unit) =
    GRow(title, sub, { on(!v) }) { Switch(v, on) }

@Composable
fun SliderRow(title: String, v: Float, range: ClosedFloatingPointRange<Float>, fmt: (Float) -> String, steps: Int = 0, on: (Float) -> Unit) {
    Glass(Modifier.fillMaxWidth(), 22.dp) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
            Row { Text(title, Modifier.weight(1f), fontSize = 15.sp); Text(fmt(v), fontSize = 14.sp) }
            Slider(v, on, valueRange = range, steps = steps)
        }
    }
}

@Composable
fun Chips(title: String, options: List<String>, sel: Int, on: (Int) -> Unit) {
    Glass(Modifier.fillMaxWidth(), 22.dp) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
            Text(title, fontSize = 15.sp); Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEachIndexed { i, o -> FilterChip(sel == i, { on(i) }, { Text(o) }) }
            }
        }
    }
}

@Composable
fun Section(t: String) = Text(t, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, top = 8.dp))

@Composable
fun Page(title: String, onBack: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") }
            Text(title, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        }
        content()
        Spacer(Modifier.height(24.dp))
    }
}

val actionNames = listOf("Ничего", "Список приложений", "Уведомления", "Поиск", "Блокировка экрана", "Настройки лаунчера", "Меню рабочего стола")
@Composable
fun ActionRow(title: String, v: Int, on: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    GRow(title, actionNames[v], { open = true }) {
        DropdownMenu(open, { open = false }) { actionNames.forEachIndexed { i, n -> DropdownMenuItem({ Text(n) }, { on(i); open = false }) } }
    }
}

fun Context.persist(u: Uri) { try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }

// ---------- Корень с 4 вкладками ----------
@Composable
fun SettingsRoot(start: String?) {
    val p = LocalPrefs.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var screen by rememberSaveable { mutableStateOf(start) }
    BackHandler(screen != null) { screen = if (screen == "hidden") "desktop" else null }
    val tabs = listOf("Персонализация" to Icons.Rounded.Home, "Энергосбережение" to Icons.Rounded.Eco,
        "Производительность" to Icons.Rounded.Speed, "О лаунчере" to Icons.Rounded.Info)
    Scaffold(containerColor = Color.Transparent, bottomBar = {
        Glass(Modifier.fillMaxWidth(), 0.dp) {
            NavigationBar(containerColor = Color.Transparent) {
                tabs.forEachIndexed { i, (n, ic) -> NavigationBarItem(tab == i, { tab = i }, { Icon(ic, n) },
                    label = { Text(n, fontSize = 10.sp, maxLines = 1) }, alwaysShowLabel = true) }
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> if (screen == null) PersonalMain { screen = it } else SubScreen(screen!!, { screen = it }) { screen = if (screen == "hidden") "desktop" else null }
                1 -> EnergyTab(); 2 -> PerfTab(); else -> AboutTab()
            }
        }
    }
}

@Composable
fun PersonalMain(go: (String) -> Unit) {
    val p = LocalPrefs.current
    Page("Настройки") {
        Section("Цвет интерфейса")
        ColorPicker("Основной цвет", p.accent) { p.accent = it; p.glassColor = it }
        Section("Оформление")
        GRow("Обои", "Свои обои, затемнение, размытие, параллакс", { go("wallpaper") }) { Icon(Icons.Rounded.ChevronRight, null) }
        GRow("Фото-виджеты", "Свои фото на главном экране", { go("photo") }) { Icon(Icons.Rounded.ChevronRight, null) }
        GRow("Liquid Glass", "Прозрачность, размытие, блики, свечение", { go("glass") }) { Icon(Icons.Rounded.ChevronRight, null) }
        GRow("Стиль иконок", "Форма, размер, расстояние, акцент", { go("icons") }) { Icon(Icons.Rounded.ChevronRight, null) }
        Chips("Тема", listOf("Системная", "Тёмная", "Светлая"), p.theme) { p.theme = it }
        Section("Организация")
        FolderTools()
        Section("Система")
        GRow("Системные настройки Android", "Wi-Fi, Bluetooth, экран, звук, батарея, яркость…", { go("system") }) { Icon(Icons.Rounded.ChevronRight, null) }
        Section("Дополнительные настройки")
        GRow("Рабочий стол", "Сетка ${p.cols}×${p.cols}, Dock, страницы", { go("desktop") }) { Icon(Icons.Rounded.ChevronRight, null) }
        GRow("Жесты", "Быстрые действия на рабочем столе", { go("gestures") }) { Icon(Icons.Rounded.ChevronRight, null) }
        GRow("Анимации", "Плавные переходы и эффекты", { go("anim") }) { Icon(Icons.Rounded.ChevronRight, null) }
    }
}

@Composable
fun SubScreen(name: String, nav: (String) -> Unit, back: () -> Unit) {
    when (name) {
        "wallpaper" -> WallpaperScreen(back); "photo" -> PhotoScreen(back); "glass" -> GlassScreen(back)
        "icons" -> IconsScreen(back); "desktop" -> DesktopScreen(back) { nav("hidden") }; "gestures" -> GestureScreen(back)
        "hidden" -> HiddenScreen(back); "system" -> SystemScreen(back); else -> AnimScreen(back)
    }
}

@Composable
fun WallpaperScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var uri by remember { mutableStateOf(p.wp) }; var dim by remember { mutableStateOf(p.dim) }
    var br by remember { mutableStateOf(p.bright) }; var bl by remember { mutableStateOf(p.wpBlur) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { ctx.persist(it); uri = it.toString() } }
    Page("Обои", back) {
        Box(Modifier.fillMaxWidth(), Alignment.Center) {
            Box(Modifier.fillMaxWidth(.5f).aspectRatio(9f / 16f).clip(RoundedCornerShape(26.dp)).border(1.dp, Color.White.copy(.5f), RoundedCornerShape(26.dp))) {
                WallpaperLayer(uri, dim, br, bl, Modifier.fillMaxSize(), false)
            }
        }
        Text("Предпросмотр", Modifier.fillMaxWidth(), fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Button({ pick.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) { Text("Выбрать из галереи") }
        SliderRow("Затемнение", dim, 0f..0.8f, { "${(it * 100).toInt()}%" }) { dim = it }
        SliderRow("Осветление", br, 0f..0.6f, { "${(it * 100).toInt()}%" }) { br = it }
        SliderRow("Размытие", bl, 0f..25f, { "${it.toInt()}" }) { bl = it }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ p.wp = uri; p.dim = dim; p.bright = br; p.wpBlur = bl; Toast.makeText(ctx, "Обои применены", Toast.LENGTH_SHORT).show() }, Modifier.weight(1f)) { Text("Применить") }
            OutlinedButton({ uri = ""; dim = .25f; br = 0f; bl = 0f }, Modifier.weight(1f)) { Text("По умолчанию") }
        }
        Toggle("Глубина и параллакс", "Обои смещаются при листании страниц", p.parallax) { p.parallax = it }
    }
}

@Composable
fun PhotoScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var target by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        us.forEach { ctx.persist(it) }; val s = us.map { it.toString() }
        if (s.isNotEmpty()) p.widgets = if (target == null) p.widgets + PhotoWidget(UUID.randomUUID().toString(), s)
            else p.widgets.map { if (it.id == target) it.copy(uris = it.uris + s) else it }
    }
    fun upd(id: String, f: (PhotoWidget) -> PhotoWidget) { p.widgets = p.widgets.map { if (it.id == id) f(it) else it } }
    Page("Фото-виджеты", back) {
        Button({ target = null; pick.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) { Text("Создать виджет из фотографий") }
        if (p.widgets.isEmpty()) Text("Виджетов пока нет. Выберите фото из галереи — виджет появится на первой странице.", fontSize = 13.sp)
        p.widgets.forEach { w ->
            Glass(Modifier.fillMaxWidth(), 22.dp) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PhotoWidgetView(w, Modifier.fillMaxWidth().height(widgetHeightDp(w.size).dp))
                Text("Фото: ${w.uris.size}", fontSize = 13.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Малый", "Средний", "Большой").forEachIndexed { i, n -> FilterChip(w.size == i, { upd(w.id) { it.copy(size = i) } }, { Text(n) }) }
                }
                Text("Скругление: ${w.corner}", fontSize = 13.sp)
                Slider(w.corner.toFloat(), { v -> upd(w.id) { it.copy(corner = v.toInt()) } }, valueRange = 0f..40f)
                Text("Прозрачность: ${(w.alpha * 100).toInt()}%", fontSize = 13.sp)
                Slider(w.alpha, { v -> upd(w.id) { it.copy(alpha = v) } }, valueRange = 0.2f..1f)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Слайд-шоу", Modifier.weight(1f)); Switch(w.slideshow, { v -> upd(w.id) { it.copy(slideshow = v) } }) }
                if (w.slideshow) { Text("Интервал: ${w.interval} с", fontSize = 13.sp)
                    Slider(w.interval.toFloat(), { v -> upd(w.id) { it.copy(interval = v.toInt()) } }, valueRange = 2f..60f) }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton({ target = w.id; pick.launch(arrayOf("image/*")) }, Modifier.weight(1f)) { Text("Добавить фото") }
                    OutlinedButton({ p.widgets = p.widgets - w }, Modifier.weight(1f)) { Text("Удалить") }
                }
            } }
        }
    }
}

@Composable
fun GlassScreen(back: () -> Unit) {
    val p = LocalPrefs.current
    Page("Liquid Glass", back) {
        Glass(Modifier.fillMaxWidth().height(90.dp)) { Text("Пример панели", Modifier.align(Alignment.Center), fontSize = 18.sp) }
        Toggle("Эффект Liquid Glass", "Выключение даёт обычные матовые панели", p.glass) { p.glass = it }
        SliderRow("Прозрачность", p.glassAlpha, 0.05f..0.6f, { "${(it * 100).toInt()}%" }) { p.glassAlpha = it }
        SliderRow("Интенсивность размытия", p.blur, 0f..40f, { "${it.toInt()}" }) { p.blur = it }
        SliderRow("Отражения и блики", p.shine, 0f..1f, { "${(it * 100).toInt()}%" }) { p.shine = it }
        SliderRow("Свечение", p.glow, 0f..1f, { "${(it * 100).toInt()}%" }) { p.glow = it }
        SliderRow("Скругление карточек", p.corner, 0f..44f, { "${it.toInt()} dp" }) { p.corner = it }
        ColorPicker("Цвет стекла", p.glassColor) { p.glassColor = it }
        Text("Реальное размытие работает на Android 12+ (иначе — полупрозрачность без блюра).", fontSize = 12.sp)
    }
}

@Composable
fun IconsScreen(back: () -> Unit) {
    val p = LocalPrefs.current
    Page("Стиль иконок", back) {
        Chips("Форма", listOf("Круглые", "Квадратные", "Скруглённые", "Стеклянные"), p.shape) { p.shape = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { IconTile(72.dp * p.iconScale) { Icon(Icons.Rounded.Star, null, tint = Color.White) } }
        SliderRow("Размер", p.iconScale, 0.7f..1.4f, { "${(it * 100).toInt()}%" }) { p.iconScale = it }
        SliderRow("Расстояние между иконками", p.gap, 0f..32f, { "${it.toInt()} dp" }) { p.gap = it }
        ColorPicker("Цветовой акцент иконок", p.accent) { p.accent = it }
    }
}

@Composable
fun DesktopScreen(back: () -> Unit, goHidden: () -> Unit) {
    val p = LocalPrefs.current
    Page("Рабочий стол", back) {
        Chips("Сетка", listOf("4×4", "5×5", "6×6"), p.cols - 4) { p.cols = it + 4 }
        SliderRow("Размер Dock", p.dockScale, 0.8f..1.3f, { "${(it * 100).toInt()}%" }) { p.dockScale = it }
        Toggle("Скрыть названия приложений", null, p.hideLabels) { p.hideLabels = it }
        SliderRow("Количество страниц", p.pages.toFloat(), 1f..6f, { "${it.toInt()}" }, 4) { p.pages = it.toInt() }
        SliderRow("Отступы", p.padding, 0f..32f, { "${it.toInt()} dp" }) { p.padding = it }
        Toggle("Часы и дата", null, p.showClock) { p.showClock = it }
        Toggle("Погода", "Нужно разрешение на примерную геолокацию (спросим при нажатии)", p.showWeather) { p.showWeather = it }
        Toggle("Строка поиска", "Строка поиска на главном экране", p.showSearch) { p.showSearch = it }
        FolderTools()
        GRow("Скрытые приложения", "${p.hidden.split(",").count { it.isNotEmpty() }} скрыто", { goHidden() }) { Icon(Icons.Rounded.ChevronRight, null) }
    }
}

@Composable
fun HiddenScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    LaunchedEffect(Unit) { apps = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { loadApps(ctx) } }
    val hidden = p.hidden.split(",").filter { it.isNotEmpty() }.toSet()
    Page("Скрытые приложения", back) {
        apps.forEach { a ->
            GRow(a.label, onClick = { p.hidden = (if (a.pkg in hidden) hidden - a.pkg else hidden + a.pkg).joinToString(",") }) {
                Switch(a.pkg in hidden, { v -> p.hidden = (if (v) hidden + a.pkg else hidden - a.pkg).joinToString(",") })
            }
        }
    }
}

@Composable
fun GestureScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    Page("Жесты", back) {
        ActionRow("Двойное нажатие", p.gDouble) { p.gDouble = it }
        ActionRow("Свайп вверх", p.gUp) { p.gUp = it }
        ActionRow("Свайп вниз", p.gDown) { p.gDown = it }
        ActionRow("Свайп вверх по Dock (поиск)", p.gDock) { p.gDock = it }
        ActionRow("Долгое нажатие на пустом месте", p.gLong) { p.gLong = it }
        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("Включить службу блокировки экрана") }
        Text("Блокировка экрана двойным нажатием работает на Android 9+ и требует включить службу «Liquid Glass Launcher» в специальных возможностях — только для действия «заблокировать экран».", fontSize = 12.sp)
    }
}

@Composable
fun AnimScreen(back: () -> Unit) {
    val p = LocalPrefs.current
    Page("Анимации", back) {
        SliderRow("Скорость анимаций", p.animSpeed, 0.5f..2f, { "×%.1f".format(it) }) { p.animSpeed = it }
        Toggle("Открытие приложений", null, p.animApps) { p.animApps = it }
        Toggle("Анимация папок", null, p.animFolder) { p.animFolder = it }
        Toggle("Переключение страниц", null, p.animPages) { p.animPages = it }
        Toggle("Появление виджетов", null, p.animWidgets) { p.animWidgets = it }
    }
}

@Composable
fun EnergyTab() {
    val p = LocalPrefs.current
    Page("Энергосбережение") {
        Toggle("Режим энергосбережения", "Отключает размытие, параллакс и замедляет слайд-шоу", p.saverManual) { p.saverManual = it }
        Toggle("Включать автоматически", "При заряде 20% и ниже", p.autoSaver) { p.autoSaver = it }
        GRow("Сейчас", if (p.saver) "Экономия включена" else "Обычный режим")
    }
}

@Composable
fun PerfTab() {
    val p = LocalPrefs.current
    Page("Производительность") {
        Chips("Профиль", listOf("Баланс", "Макс. качество", "Эконом"), p.perf) { p.perf = it }
        Toggle("Размытие под панелями", "Самый затратный эффект (Android 12+)", p.blurPanels) { p.blurPanels = it }
        Toggle("Параллакс обоев", null, p.parallax) { p.parallax = it }
        Text("«Эконом» выключает размытие панелей. Скорость анимаций — в разделе «Анимации».", fontSize = 12.sp)
    }
}

@Composable
fun AboutTab() {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val role = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        u?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(p.export().toByteArray()) }; Toast.makeText(ctx, "Копия сохранена", Toast.LENGTH_SHORT).show() } }
    val load = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u?.let { try { p.import(ctx.contentResolver.openInputStream(it)!!.bufferedReader().readText()); Toast.makeText(ctx, "Настройки восстановлены", Toast.LENGTH_SHORT).show() }
            catch (e: Exception) { Toast.makeText(ctx, "Неверный файл", Toast.LENGTH_SHORT).show() } } }
    Page("О лаунчере") {
        GRow("Liquid Glass Launcher", "Версия 1.0")
        Button({
            if (android.os.Build.VERSION.SDK_INT >= 29) role.launch(ctx.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_HOME))
            else ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }, Modifier.fillMaxWidth()) { Text("Сделать лаунчером по умолчанию") }
        OutlinedButton({ save.launch("liquid-glass-backup.json") }, Modifier.fillMaxWidth()) { Text("Резервная копия настроек") }
        OutlinedButton({ load.launch(arrayOf("application/json", "*/*")) }, Modifier.fillMaxWidth()) { Text("Восстановить настройки") }
        OutlinedButton({ confirm = true }, Modifier.fillMaxWidth()) { Text("Сбросить лаунчер") }
    }
    if (confirm) AlertDialog({ confirm = false }, title = { Text("Сбросить лаунчер?") }, text = { Text("Все настройки, раскладка и фото-виджеты будут удалены.") },
        confirmButton = { TextButton({ p.reset(); confirm = false }) { Text("Сбросить") } }, dismissButton = { TextButton({ confirm = false }) { Text("Отмена") } })
}

@Composable
fun ColorPicker(title: String, sel: Int, on: (Int) -> Unit) {
    val p = LocalPrefs.current
    Glass(Modifier.fillMaxWidth(), 22.dp) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
            Text(title, fontSize = 15.sp); Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                (0..Palette.size).forEach { i ->
                    Box(Modifier.size(38.dp).clip(CircleShape).background(p.color(i))
                        .border(if (sel == i) 3.dp else 1.dp, if (sel == i) Color.White else Color.White.copy(.4f), CircleShape)
                        .clickable { on(i) }, contentAlignment = Alignment.Center) {
                        if (i == Palette.size) Text("+", color = Color.White, fontSize = 20.sp)
                    }
                }
            }
            if (sel >= Palette.size) { Text("Свой оттенок", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)); Slider(p.hue, { p.hue = it }, valueRange = 0f..360f) }
        }
    }
}

@Composable
fun FolderTools() {
    val p = LocalPrefs.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    Button({
        scope.launch {
            val m = HomeModel(p); m.refresh(ctx.applicationContext); val n = m.autoFolders()
            Toast.makeText(ctx, if (n > 0) "Создано папок: $n" else "Нечего группировать", Toast.LENGTH_SHORT).show()
        }
    }, Modifier.fillMaxWidth()) { Text("Разложить приложения по папкам (Игры, Google…)") }
    OutlinedButton({
        scope.launch { val m = HomeModel(p); m.refresh(ctx.applicationContext); m.dissolveAll(); Toast.makeText(ctx, "Папки расформированы", Toast.LENGTH_SHORT).show() }
    }, Modifier.fillMaxWidth()) { Text("Расформировать все папки") }
}

@Composable
fun SystemScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var canWrite by remember { mutableStateOf(Settings.System.canWrite(ctx)) }
    val grant = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { canWrite = Settings.System.canWrite(ctx) }
    fun open(a: String) { try { ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, "Недоступно на этом устройстве", Toast.LENGTH_SHORT).show() } }
    Page("Системные настройки", back) {
        Section("Быстрое управление")
        SliderRow("Громкость мультимедиа", vol, 0f..maxV.toFloat(), { "${it.toInt()}/$maxV" }, maxOf(0, maxV - 1)) {
            vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) }
        if (canWrite) {
            var br by remember { mutableFloatStateOf(try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS).toFloat() } catch (e: Exception) { 128f }) }
            SliderRow("Яркость экрана", br, 1f..255f, { "${(it / 2.55f).toInt()}%" }) {
                br = it
                try {
                    Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, it.toInt())
                } catch (e: Exception) {}
            }
        } else GRow("Яркость экрана", "Нажмите, чтобы разрешить изменение системных настроек", {
            grant.launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName))) })
        Section("Открыть настройки Android")
        listOf(
            Triple("Wi-Fi", "Сети и подключение", Settings.ACTION_WIFI_SETTINGS),
            Triple("Bluetooth", "Устройства", Settings.ACTION_BLUETOOTH_SETTINGS),
            Triple("Мобильная сеть", "SIM и передача данных", Settings.ACTION_DATA_ROAMING_SETTINGS),
            Triple("Режим полёта", "Беспроводные сети", Settings.ACTION_AIRPLANE_MODE_SETTINGS),
            Triple("Экран", "Яркость, тёмная тема, тайм-аут", Settings.ACTION_DISPLAY_SETTINGS),
            Triple("Звук и вибрация", "Громкость, рингтоны", Settings.ACTION_SOUND_SETTINGS),
            Triple("Батарея", "Режим энергосбережения Android", Settings.ACTION_BATTERY_SAVER_SETTINGS),
            Triple("Приложения", "Управление приложениями", Settings.ACTION_APPLICATION_SETTINGS),
            Triple("Память", "Хранилище", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
            Triple("Геолокация", "Службы определения места", Settings.ACTION_LOCATION_SOURCE_SETTINGS),
            Triple("Приложения по умолчанию", "Браузер, звонки, лаунчер", Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Triple("Специальные возможности", "Службы и жесты", Settings.ACTION_ACCESSIBILITY_SETTINGS),
            Triple("Язык", "Язык системы", Settings.ACTION_LOCALE_SETTINGS),
            Triple("Дата и время", "Часовой пояс", Settings.ACTION_DATE_SETTINGS),
            Triple("Все настройки Android", "Главное меню настроек", Settings.ACTION_SETTINGS)
        ).forEach { (t, sub, a) -> GRow(t, sub, { open(a) }) { Icon(Icons.Rounded.ChevronRight, null) } }
    }
}
