package com.liquidglass.launcher

import android.app.role.RoleManager
import android.appwidget.AppWidgetHost
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.launch
import java.util.UUID

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = Prefs(this); prefs.updateBattery(this)
        val start = intent.getStringExtra("screen")
        setContent { Backdrop(prefs, remember { mutableStateOf(0f) }) { CompositionLocalProvider(LocalGlassBlur provides false) { SettingsRoot(start) } } }
    }
}

// ======================= Базовые элементы =======================
// Принцип: строки собираются в GGroup — одну стеклянную карточку с тонкими разделителями.
// Вне группы те же строки рисуются как самостоятельные карточки, поэтому старые экраны не ломаются.

val LocalInGroup = compositionLocalOf { false }

@Composable private fun accentColor(): Color { val p = LocalPrefs.current; return p.color(p.accent) }
@Composable private fun onAccentColor(): Color = if (accentColor().luminance() > .55f) Color.Black else Color.White

@Composable
private fun RowSurface(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    if (LocalInGroup.current) Box(modifier.fillMaxWidth(), content = content)
    else Glass(modifier.fillMaxWidth(), 22.dp, content)
}

/** Карточка-группа: заголовок раздела, одна стеклянная панель, разделители между строками, пояснение под ней. */
@Composable
fun GGroup(title: String? = null, note: String? = null, content: @Composable () -> Unit) {
    if (title != null) Section(title)
    val line = LocalContentColor.current.copy(.13f)
    val ys = remember { ArrayList<Float>() }
    CompositionLocalProvider(LocalInGroup provides true) {
        Glass(Modifier.fillMaxWidth(), 22.dp) {
            Layout(content, Modifier.fillMaxWidth().drawBehind {
                ys.forEach { y -> drawLine(line, Offset(16.dp.toPx(), y), Offset(size.width, y), 1.dp.toPx()) }
            }) { ms, c ->
                val ps = ms.map { it.measure(c.copy(minWidth = c.maxWidth, minHeight = 0)) }
                ys.clear(); var y = 0
                ps.forEachIndexed { i, pl -> if (i > 0) ys += y.toFloat(); y += pl.height }
                layout(c.maxWidth, y) { var yy = 0; ps.forEach { it.placeRelative(0, yy); yy += it.height } }
            }
        }
    }
    if (note != null) GNote(note)
}

@Composable
fun GNote(t: String) = Text(t, Modifier.padding(horizontal = 10.dp).alpha(.68f), fontSize = 12.sp, lineHeight = 16.sp)

@Composable
fun Section(t: String) {
    val ac = accentColor()
    Text(t, Modifier.padding(start = 8.dp, top = 14.dp).semantics { heading() }, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        color = if (LocalDark.current) ac else lerp(ac, Color.Black, .35f))
}

@Composable
fun IconBadge(icon: ImageVector, tint: Color? = null) {
    val c = tint ?: accentColor()
    Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(Brush.linearGradient(listOf(c.copy(.95f), c.copy(.6f)))), Alignment.Center) {
        Icon(icon, null, Modifier.size(20.dp), tint = if (c.luminance() > .55f) Color.Black else Color.White)
    }
}

@Composable fun Chevron() = Icon(Icons.Rounded.ChevronRight, null, Modifier.alpha(.55f))

@Composable
private fun ValuePill(text: String) {
    Box(Modifier.clip(RoundedCornerShape(10.dp)).background(accentColor().copy(.22f)).padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun GRow(title: String, sub: String? = null, onClick: (() -> Unit)? = null, icon: ImageVector? = null, tint: Color? = null,
         trailing: @Composable () -> Unit = {}) {
    val click = if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier
    RowSurface(click) {
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { IconBadge(icon, tint); Spacer(Modifier.width(14.dp)) }
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                if (sub != null) Text(sub, Modifier.alpha(.68f), fontSize = 13.sp, lineHeight = 17.sp)
            }
            trailing()
        }
    }
}

@Composable
fun ToggleRow(title: String, sub: String?, v: Boolean, leading: (@Composable () -> Unit)? = null, on: (Boolean) -> Unit) {
    RowSurface(Modifier.toggleable(value = v, role = Role.Switch, onValueChange = on)) {
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (leading != null) { leading(); Spacer(Modifier.width(14.dp)) }
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                if (sub != null) Text(sub, Modifier.alpha(.68f), fontSize = 13.sp, lineHeight = 17.sp)
            }
            Switch(v, null, colors = SwitchDefaults.colors(checkedTrackColor = accentColor(), checkedThumbColor = onAccentColor()))
        }
    }
}

@Composable fun Toggle(title: String, sub: String? = null, v: Boolean, on: (Boolean) -> Unit) = ToggleRow(title, sub, v, null, on)

@Composable
fun SliderRow(title: String, v: Float, range: ClosedFloatingPointRange<Float>, fmt: (Float) -> String, steps: Int = 0, on: (Float) -> Unit) {
    val ac = accentColor()
    RowSurface {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(Modifier.heightIn(min = 32.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), fontSize = 15.sp); ValuePill(fmt(v))
            }
            Slider(v, on, Modifier.semantics { contentDescription = title }, valueRange = range, steps = steps,
                colors = SliderDefaults.colors(thumbColor = ac, activeTrackColor = ac, inactiveTrackColor = LocalContentColor.current.copy(.18f)))
        }
    }
}

/** Переключатель вариантов: до 3 коротких — сегменты на всю ширину, иначе — прокручиваемая лента. */
@Composable
fun Chips(title: String, options: List<String>, sel: Int, on: (Int) -> Unit) {
    val ac = accentColor(); val onAc = onAccentColor(); val seg = options.size <= 3
    RowSurface {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(title, fontSize = 15.sp); Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LocalContentColor.current.copy(.1f)).padding(3.dp)
                .then(if (seg) Modifier else Modifier.horizontalScroll(rememberScrollState())), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                options.forEachIndexed { i, o ->
                    val chosen = sel == i
                    Box(Modifier.then(if (seg) Modifier.weight(1f) else Modifier).heightIn(min = 44.dp).clip(RoundedCornerShape(11.dp))
                        .background(if (chosen) ac else Color.Transparent)
                        .selectable(chosen, role = Role.RadioButton, onClick = { on(i) }).padding(horizontal = 14.dp), Alignment.Center) {
                        Text(o, fontSize = 14.sp, maxLines = 1, fontWeight = if (chosen) FontWeight.SemiBold else FontWeight.Medium,
                            color = if (chosen) onAc else LocalContentColor.current)
                    }
                }
            }
        }
    }
}

@Composable
fun ColorPicker(title: String, sel: Int, on: (Int) -> Unit) {
    val p = LocalPrefs.current
    RowSurface {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(title, fontSize = 15.sp); Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                (0..Palette.size).forEach { i ->
                    val c = p.color(i); val chosen = sel == i
                    val name = PaletteNames.getOrElse(i) { "Свой" }
                    Box(Modifier.size(48.dp).selectable(chosen, role = Role.RadioButton, onClick = { on(i) })
                        .semantics { contentDescription = name }, Alignment.Center) {
                        Box(Modifier.size(if (chosen) 38.dp else 32.dp).clip(CircleShape).background(c)
                            .border(if (chosen) 3.dp else 1.dp, if (chosen) LocalContentColor.current else LocalContentColor.current.copy(.35f), CircleShape),
                            Alignment.Center) {
                            if (chosen) Icon(Icons.Rounded.Check, null, Modifier.size(18.dp), tint = if (c.luminance() > .55f) Color.Black else Color.White)
                            else if (i == Palette.size) Text("+", color = Color.White, fontSize = 18.sp)
                        }
                    }
                }
            }
            if (sel >= Palette.size) {
                Text("Оттенок", Modifier.padding(top = 4.dp).alpha(.7f), fontSize = 13.sp)
                Slider(p.hue, { p.hue = it }, Modifier.semantics { contentDescription = "Оттенок" }, valueRange = 0f..360f)
            }
        }
    }
}

@Composable
fun GButton(text: String, primary: Boolean = false, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) {
    val m = modifier.heightIn(min = 52.dp)
    if (primary) Button(onClick, m, shape = RoundedCornerShape(16.dp)) { Text(text, fontWeight = FontWeight.SemiBold) }
    else OutlinedButton(onClick, m, shape = RoundedCornerShape(16.dp)) { Text(text) }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismiss, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton({ onConfirm(); onDismiss() }) { Text(confirm) } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } })
}

/** Страница: закреплённая шапка (назад + крупный заголовок) и прокручиваемое содержимое. */
@Composable
fun Page(title: String, onBack: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = if (onBack != null) 8.dp else 20.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                Box(Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onBack)
                    .semantics { contentDescription = "Назад" }, Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
                Spacer(Modifier.width(4.dp))
            }
            Text(title, Modifier.semantics { heading() }, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            content()
            Spacer(Modifier.height(24.dp))
        }
    }
}

val actionNames = listOf("Ничего", "Список приложений", "Уведомления", "Поиск", "Блокировка экрана", "Настройки лаунчера", "Меню рабочего стола")
@Composable
fun ActionRow(title: String, v: Int, on: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    GRow(title, actionNames[v], { open = true }) {
        Box {
            Chevron()
            DropdownMenu(open, { open = false }) { actionNames.forEachIndexed { i, n -> DropdownMenuItem({ Text(n) }, { on(i); open = false }) } }
        }
    }
}

fun Context.persist(u: Uri) { try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }

@Composable
private fun SearchField(q: String, hint: String, onChange: (String) -> Unit) {
    Glass(Modifier.fillMaxWidth(), 20.dp) {
        Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, null, Modifier.alpha(.7f)); Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f)) {
                BasicTextField(q, onChange, Modifier.fillMaxWidth().semantics { contentDescription = hint }, singleLine = true,
                    textStyle = TextStyle(color = LocalContentColor.current, fontSize = 16.sp), cursorBrush = SolidColor(accentColor()),
                    decorationBox = { inner -> if (q.isEmpty()) Text(hint, Modifier.alpha(.6f), fontSize = 16.sp); inner() })
            }
            if (q.isNotEmpty()) Box(Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button) { onChange("") }
                .semantics { contentDescription = "Очистить поиск" }, Alignment.Center) { Icon(Icons.Rounded.Close, null) }
        }
    }
}

// ======================= Корень =======================
private data class SItem(val title: String, val where: String, val section: String, val icon: ImageVector, val keys: String)
private val settingsIndex = listOf(
    SItem("Обои", "wallpaper", "Обои", Icons.Rounded.Wallpaper, "фон картинка фото галерея"),
    SItem("Затемнение обоев", "wallpaper", "Обои", Icons.Rounded.Wallpaper, "dim темнее"),
    SItem("Размытие обоев", "wallpaper", "Обои", Icons.Rounded.Wallpaper, "блюр blur"),
    SItem("Параллакс", "wallpaper", "Обои", Icons.Rounded.Wallpaper, "глубина смещение"),
    SItem("Живые обои", "wallpaper", "Обои", Icons.Rounded.Wallpaper, "системные"),
    SItem("Эффект Liquid Glass", "glass", "Liquid Glass", Icons.Rounded.BlurOn, "стекло панели"),
    SItem("Прозрачность стекла", "glass", "Liquid Glass", Icons.Rounded.BlurOn, "альфа"),
    SItem("Размытие панелей", "glass", "Liquid Glass", Icons.Rounded.BlurOn, "блюр blur"),
    SItem("Блики и свечение", "glass", "Liquid Glass", Icons.Rounded.BlurOn, "отражения glow shine"),
    SItem("Преломление у краёв", "glass", "Liquid Glass", Icons.Rounded.BlurOn, "линза refraction"),
    SItem("Скругление карточек", "glass", "Liquid Glass", Icons.Rounded.BlurOn, "радиус углы"),
    SItem("Форма иконок", "icons", "Стиль иконок", Icons.Rounded.Palette, "круглые квадратные"),
    SItem("Размер иконок", "icons", "Стиль иконок", Icons.Rounded.Palette, "масштаб"),
    SItem("Темизированные иконки", "icons", "Стиль иконок", Icons.Rounded.Palette, "monochrome одноцветные"),
    SItem("Счётчики уведомлений", "icons", "Стиль иконок", Icons.Rounded.Palette, "бейджи значки"),
    SItem("Сетка рабочего стола", "desktop", "Рабочий стол", Icons.Rounded.GridView, "колонки 4x4 5x5 6x6"),
    SItem("Dock", "desktop", "Рабочий стол", Icons.Rounded.GridView, "панель снизу"),
    SItem("Страницы", "desktop", "Рабочий стол", Icons.Rounded.GridView, "количество экранов"),
    SItem("Названия приложений", "desktop", "Рабочий стол", Icons.Rounded.GridView, "подписи"),
    SItem("Часы и погода", "desktop", "Рабочий стол", Icons.Rounded.GridView, "дата геолокация"),
    SItem("Строка поиска", "desktop", "Рабочий стол", Icons.Rounded.GridView, "поиск на главном"),
    SItem("Скрытые приложения", "hidden", "Приложения", Icons.Rounded.VisibilityOff, "спрятать"),
    SItem("Жесты", "gestures", "Жесты", Icons.Rounded.Gesture, "свайп двойное нажатие долгое"),
    SItem("Блокировка экрана", "gestures", "Жесты", Icons.Rounded.Gesture, "двойной тап служба"),
    SItem("Анимации", "anim", "Анимации", Icons.Rounded.Animation, "скорость переходы"),
    SItem("Фото-виджеты", "photo", "Фото-виджеты", Icons.Rounded.PhotoLibrary, "слайд-шоу галерея"),
    SItem("Виджеты Android", "widgets", "Виджеты Android", Icons.Rounded.Widgets, "высота удалить"),
    SItem("Wi-Fi, яркость, громкость", "system", "Система", Icons.Rounded.Settings, "bluetooth звук экран"),
    SItem("Энергосбережение", "tab:1", "Энергия", Icons.Rounded.Eco, "батарея экономия"),
    SItem("Производительность", "tab:2", "Скорость", Icons.Rounded.Speed, "профиль эконом качество"),
    SItem("Резервная копия и сброс", "tab:3", "О приложении", Icons.Rounded.Info, "восстановить экспорт импорт лаунчер по умолчанию")
)

@Composable
fun SettingsRoot(start: String?) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var screen by rememberSaveable { mutableStateOf(start) }
    var parent by rememberSaveable { mutableStateOf<String?>(null) }
    val back = { screen = if (screen == "hidden") parent else null }
    val nav: (String) -> Unit = { to ->
        if (to.startsWith("tab:")) { tab = to.removePrefix("tab:").toInt(); screen = null } else { parent = screen; screen = to }
    }
    BackHandler(screen != null && tab == 0) { back() }
    val tabs = listOf("Стиль" to Icons.Rounded.Palette, "Энергия" to Icons.Rounded.Eco,
        "Скорость" to Icons.Rounded.Speed, "О лаунчере" to Icons.Rounded.Info)
    Scaffold(containerColor = Color.Transparent, bottomBar = {
        Glass(Modifier.fillMaxWidth(), 0.dp) {
            NavigationBar(containerColor = Color.Transparent) {
                tabs.forEachIndexed { i, (n, ic) -> NavigationBarItem(tab == i, { tab = i }, { Icon(ic, null) },
                    label = { Text(n, fontSize = 11.sp, maxLines = 1) }, alwaysShowLabel = true) }
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> if (screen == null) PersonalMain(nav) else SubScreen(screen!!, nav, back)
                1 -> EnergyTab(); 2 -> PerfTab(); else -> AboutTab()
            }
        }
    }
}

@Composable
private fun Hero() {
    CompositionLocalProvider(LocalGlassBlur provides true) {
        Glass(Modifier.fillMaxWidth().height(96.dp), 28.dp) {
            Row(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                IconTile(56.dp) { Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White) }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Liquid Glass", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("Так сейчас выглядят панели", Modifier.alpha(.7f), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun PersonalMain(go: (String) -> Unit) {
    val p = LocalPrefs.current
    var q by rememberSaveable { mutableStateOf("") }
    Page("Настройки") {
        SearchField(q, "Поиск по настройкам") { q = it }
        if (q.isNotBlank()) {
            val words = q.trim().lowercase().split(' ').filter { it.isNotEmpty() }
            val hits = settingsIndex.filter { s -> val hay = (s.title + " " + s.section + " " + s.keys).lowercase(); words.all { it in hay } }
            if (hits.isEmpty()) GNote("Ничего не найдено. Попробуйте другое слово, например «размытие» или «сетка».")
            else GGroup { hits.forEach { h -> GRow(h.title, "Раздел: ${h.section}", { go(h.where) }, h.icon) { Chevron() } } }
        } else {
            Hero()
            GGroup("Быстрая настройка") {
                ColorPicker("Цвет интерфейса", p.accent) { p.accent = it; p.glassColor = it }
                Chips("Тема", listOf("Системная", "Тёмная", "Светлая"), p.theme) { p.theme = it }
            }
            GGroup("Внешний вид") {
                GRow("Обои", "Фото, затемнение, размытие, параллакс", { go("wallpaper") }, Icons.Rounded.Wallpaper) { Chevron() }
                GRow("Liquid Glass", "Прозрачность, размытие, блики, свечение", { go("glass") }, Icons.Rounded.BlurOn) { Chevron() }
                GRow("Стиль иконок", "Форма, размер, расстояние, бейджи", { go("icons") }, Icons.Rounded.Palette) { Chevron() }
            }
            GGroup("Рабочий стол") {
                GRow("Рабочий стол", "Сетка ${p.cols}×${p.cols}, Dock, страницы", { go("desktop") }, Icons.Rounded.GridView) { Chevron() }
                GRow("Жесты", "Быстрые действия на рабочем столе", { go("gestures") }, Icons.Rounded.Gesture) { Chevron() }
                GRow("Анимации", "Плавные переходы и эффекты", { go("anim") }, Icons.Rounded.Animation) { Chevron() }
            }
            GGroup("Виджеты") {
                GRow("Фото-виджеты", if (p.widgets.isEmpty()) "Свои фото на главном экране" else "Создано: ${p.widgets.size}", { go("photo") }, Icons.Rounded.PhotoLibrary) { Chevron() }
                GRow("Виджеты Android", if (p.hosted.isEmpty()) "Добавляются долгим нажатием на пустом месте" else "На рабочем столе: ${p.hosted.size}", { go("widgets") }, Icons.Rounded.Widgets) { Chevron() }
            }
            GGroup("Приложения") {
                GRow("Скрытые приложения", "Скрыто: ${p.hidden.split(",").count { it.isNotEmpty() }}", { go("hidden") }, Icons.Rounded.VisibilityOff) { Chevron() }
                FolderRows()
            }
            GGroup("Система") {
                GRow("Настройки Android", "Wi-Fi, Bluetooth, экран, звук, яркость", { go("system") }, Icons.Rounded.Settings) { Chevron() }
            }
        }
    }
}

@Composable
fun SubScreen(name: String, nav: (String) -> Unit, back: () -> Unit) {
    when (name) {
        "wallpaper" -> WallpaperScreen(back); "photo" -> PhotoScreen(back); "glass" -> GlassScreen(back)
        "icons" -> IconsScreen(back); "desktop" -> DesktopScreen(back) { nav("hidden") }; "gestures" -> GestureScreen(back)
        "hidden" -> HiddenScreen(back); "system" -> SystemScreen(back); "widgets" -> WidgetsScreen(back); else -> AnimScreen(back)
    }
}

// ======================= Экраны =======================
@Composable
fun WallpaperScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var uri by remember { mutableStateOf(p.wp) }; var dim by remember { mutableStateOf(p.dim) }
    var br by remember { mutableStateOf(p.bright) }; var bl by remember { mutableStateOf(p.wpBlur) }
    val changed = uri != p.wp || dim != p.dim || br != p.bright || bl != p.wpBlur
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { ctx.persist(it); uri = it.toString() } }
    Page("Обои", back) {
        Box(Modifier.fillMaxWidth(), Alignment.Center) {
            Box(Modifier.fillMaxWidth(.5f).aspectRatio(9f / 16f).clip(RoundedCornerShape(26.dp)).border(1.dp, Color.White.copy(.5f), RoundedCornerShape(26.dp))) {
                WallpaperLayer(uri, dim, br, bl, Modifier.fillMaxSize(), false)
            }
        }
        Text("Предпросмотр", Modifier.fillMaxWidth().alpha(.7f), fontSize = 12.sp, textAlign = TextAlign.Center)
        GButton("Выбрать из галереи", primary = true) { pick.launch(arrayOf("image/*")) }
        GGroup("Настройка фона") {
            SliderRow("Затемнение", dim, 0f..0.8f, { "${(it * 100).toInt()}%" }) { dim = it }
            SliderRow("Осветление", br, 0f..0.6f, { "${(it * 100).toInt()}%" }) { br = it }
            SliderRow("Размытие", bl, 0f..25f, { "${it.toInt()}" }) { bl = it }
        }
        if (changed) GNote("Есть неприменённые изменения — нажмите «Применить».")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GButton("Применить", primary = true, modifier = Modifier.weight(1f)) {
                p.wp = uri; p.dim = dim; p.bright = br; p.wpBlur = bl; Toast.makeText(ctx, "Обои применены", Toast.LENGTH_SHORT).show() }
            GButton("По умолчанию", modifier = Modifier.weight(1f)) { uri = ""; dim = .25f; br = 0f; bl = 0f }
        }
        GGroup("Режим обоев") {
            Toggle("Системные / живые обои", "Показывать обои Android вместо своего фото (без размытия под панелями и параллакса)", p.sysWp) { p.sysWp = it }
            Toggle("Глубина и параллакс", "Обои смещаются при листании страниц", p.parallax) { p.parallax = it }
        }
    }
}

@Composable
fun PhotoScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var target by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<PhotoWidget?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        us.forEach { ctx.persist(it) }; val s = us.map { it.toString() }
        if (s.isNotEmpty()) p.widgets = if (target == null) p.widgets + PhotoWidget(UUID.randomUUID().toString(), s)
            else p.widgets.map { if (it.id == target) it.copy(uris = it.uris + s) else it }
    }
    fun upd(id: String, f: (PhotoWidget) -> PhotoWidget) { p.widgets = p.widgets.map { if (it.id == id) f(it) else it } }
    Page("Фото-виджеты", back) {
        GButton("Создать виджет из фотографий", primary = true) { target = null; pick.launch(arrayOf("image/*")) }
        if (p.widgets.isEmpty()) GNote("Виджетов пока нет. Выберите фото из галереи — виджет появится на первой странице.")
        p.widgets.forEachIndexed { idx, w ->
            GGroup("Виджет ${idx + 1}, фото: ${w.uris.size}") {
                Box(Modifier.padding(12.dp)) { PhotoWidgetView(w, Modifier.fillMaxWidth().height(widgetHeightDp(w.size).dp)) }
                Chips("Размер", listOf("Малый", "Средний", "Большой"), w.size) { i -> upd(w.id) { it.copy(size = i) } }
                SliderRow("Скругление", w.corner.toFloat(), 0f..40f, { "${it.toInt()} dp" }) { v -> upd(w.id) { it.copy(corner = v.toInt()) } }
                SliderRow("Прозрачность", w.alpha, 0.2f..1f, { "${(it * 100).toInt()}%" }) { v -> upd(w.id) { it.copy(alpha = v) } }
                Toggle("Слайд-шоу", null, w.slideshow) { v -> upd(w.id) { it.copy(slideshow = v) } }
                if (w.slideshow) SliderRow("Интервал", w.interval.toFloat(), 2f..60f, { "${it.toInt()} с" }) { v -> upd(w.id) { it.copy(interval = v.toInt()) } }
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GButton("Добавить фото", modifier = Modifier.weight(1f)) { target = w.id; pick.launch(arrayOf("image/*")) }
                    GButton("Удалить", modifier = Modifier.weight(1f)) { deleting = w }
                }
            }
        }
    }
    deleting?.let { w -> ConfirmDialog("Удалить виджет?", "Фото на устройстве останутся, пропадёт только виджет.", "Удалить", { p.widgets = p.widgets - w }) { deleting = null } }
}

@Composable
fun GlassScreen(back: () -> Unit) {
    val p = LocalPrefs.current
    Page("Liquid Glass", back) {
        CompositionLocalProvider(LocalGlassBlur provides true) {
            Glass(Modifier.fillMaxWidth().height(96.dp)) { Text("Пример панели", Modifier.align(Alignment.Center), fontSize = 18.sp) }
        }
        GGroup("Эффект") {
            Toggle("Эффект Liquid Glass", "Выключение даёт обычные матовые панели", p.glass) { p.glass = it }
            Toggle("Преломление у краёв", "Эффект линзы на кромке панелей, Android 13+ (нужен включённый блюр)", p.refract) { p.refract = it }
        }
        GGroup("Параметры стекла") {
            SliderRow("Прозрачность", p.glassAlpha, 0.05f..0.6f, { "${(it * 100).toInt()}%" }) { p.glassAlpha = it }
            SliderRow("Интенсивность размытия", p.blur, 0f..40f, { "${it.toInt()}" }) { p.blur = it }
            SliderRow("Отражения и блики", p.shine, 0f..1f, { "${(it * 100).toInt()}%" }) { p.shine = it }
            SliderRow("Свечение", p.glow, 0f..1f, { "${(it * 100).toInt()}%" }) { p.glow = it }
            SliderRow("Скругление карточек", p.corner, 0f..44f, { "${it.toInt()} dp" }) { p.corner = it }
        }
        GGroup("Цвет", "Реальное размытие работает на Android 12+, иначе — полупрозрачность без блюра.") {
            ColorPicker("Цвет стекла", p.glassColor) { p.glassColor = it }
        }
    }
}

@Composable
fun IconsScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    Page("Стиль иконок", back) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.Center) {
            IconTile(72.dp * p.iconScale) { Icon(Icons.Rounded.Star, null, tint = Color.White) }
        }
        GGroup("Форма и размер") {
            Chips("Форма", listOf("Круглые", "Квадратные", "Скруглённые", "Стеклянные"), p.shape) { p.shape = it }
            SliderRow("Размер", p.iconScale, 0.7f..1.4f, { "${(it * 100).toInt()}%" }) { p.iconScale = it }
            SliderRow("Расстояние между иконками", p.gap, 0f..32f, { "${it.toInt()} dp" }) { p.gap = it }
        }
        GGroup("Цвет") {
            ColorPicker("Цветовой акцент иконок", p.accent) { p.accent = it }
            Toggle("Темизированные иконки", "Одноцветные иконки в цвет акцента (Android 13+, если приложение их поддерживает)", p.themed) { p.themed = it }
        }
        GGroup("Уведомления", "Доступ нужен только для подсчёта уведомлений; тексты не читаются и не сохраняются.") {
            Toggle("Счётчики уведомлений", "Красные бейджи на иконках", p.badges) { p.badges = it }
            GRow("Доступ к уведомлениям", if (granted) "Включён" else "Выключен — нажмите, чтобы разрешить",
                { try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) {} }) { Chevron() }
        }
    }
}

@Composable
fun DesktopScreen(back: () -> Unit, goHidden: () -> Unit) {
    val p = LocalPrefs.current
    Page("Рабочий стол", back) {
        GGroup("Сетка и страницы") {
            Chips("Сетка", listOf("4×4", "5×5", "6×6"), p.cols - 4) { p.cols = it + 4 }
            SliderRow("Количество страниц", p.pages.toFloat(), 1f..6f, { "${it.toInt()}" }, 4) { p.pages = it.toInt() }
            SliderRow("Отступы", p.padding, 0f..32f, { "${it.toInt()} dp" }) { p.padding = it }
            SliderRow("Размер Dock", p.dockScale, 0.8f..1.3f, { "${(it * 100).toInt()}%" }) { p.dockScale = it }
        }
        GGroup("На главном экране") {
            Toggle("Часы и дата", null, p.showClock) { p.showClock = it }
            Toggle("Погода", "Нужно разрешение на примерную геолокацию (спросим при нажатии)", p.showWeather) { p.showWeather = it }
            Toggle("Строка поиска", "Строка поиска на главном экране", p.showSearch) { p.showSearch = it }
            Toggle("Скрыть названия приложений", null, p.hideLabels) { p.hideLabels = it }
        }
        GGroup("Приложения") {
            GRow("Скрытые приложения", "Скрыто: ${p.hidden.split(",").count { it.isNotEmpty() }}", { goHidden() }, Icons.Rounded.VisibilityOff) { Chevron() }
            FolderRows()
        }
    }
}

@Composable
fun HiddenScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { loadApps(ctx) } }
    val hidden = p.hidden.split(",").filter { it.isNotEmpty() }.toSet()
    val shown = apps.filter { q.isBlank() || it.label.contains(q.trim(), ignoreCase = true) }
    Page("Скрытые приложения", back) {
        SearchField(q, "Найти приложение") { q = it }
        if (apps.isEmpty()) GNote("Загружаю список приложений…")
        else if (shown.isEmpty()) GNote("Ничего не найдено.")
        else GGroup(note = "Скрыто: ${hidden.size}. Скрытые приложения не показываются на рабочем столе, но остаются в системе.") {
            shown.forEach { a ->
                ToggleRow(a.label, null, a.pkg in hidden, { Image(a.icon, null, Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))) }) { v ->
                    p.hidden = (if (v) hidden + a.pkg else hidden - a.pkg).joinToString(",")
                }
            }
        }
    }
}

@Composable
fun GestureScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    Page("Жесты", back) {
        GGroup("Действия") {
            ActionRow("Двойное нажатие", p.gDouble) { p.gDouble = it }
            ActionRow("Свайп вверх", p.gUp) { p.gUp = it }
            ActionRow("Свайп вниз", p.gDown) { p.gDown = it }
            ActionRow("Свайп вверх по Dock", p.gDock) { p.gDock = it }
            ActionRow("Долгое нажатие на пустом месте", p.gLong) { p.gLong = it }
        }
        GGroup("Блокировка экрана",
            "Блокировка двойным нажатием работает на Android 9+ и требует включить службу «Liquid Glass Launcher» в специальных возможностях — только для действия «заблокировать экран».") {
            GRow("Включить службу блокировки", "Откроются специальные возможности", { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                Icons.Rounded.Lock) { Chevron() }
            GRow("Служба недоступна?", "«О приложении» → ⋮ → «Разрешить ограниченные настройки»",
                { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))) }) { Chevron() }
        }
    }
}

@Composable
fun AnimScreen(back: () -> Unit) {
    val p = LocalPrefs.current
    Page("Анимации", back) {
        GGroup { SliderRow("Скорость анимаций", p.animSpeed, 0.5f..2f, { "×%.1f".format(it) }) { p.animSpeed = it } }
        GGroup("Где использовать") {
            Toggle("Открытие приложений", null, p.animApps) { p.animApps = it }
            Toggle("Анимация папок", null, p.animFolder) { p.animFolder = it }
            Toggle("Переключение страниц", null, p.animPages) { p.animPages = it }
            Toggle("Появление виджетов", null, p.animWidgets) { p.animWidgets = it }
        }
    }
}

@Composable
fun EnergyTab() {
    val p = LocalPrefs.current
    Page("Энергосбережение") {
        GGroup("Режим экономии", "Экономия отключает размытие, параллакс и замедляет слайд-шоу.") {
            Toggle("Режим энергосбережения", "Включить вручную", p.saverManual) { p.saverManual = it }
            Toggle("Включать автоматически", "При заряде 20% и ниже", p.autoSaver) { p.autoSaver = it }
        }
        GGroup("Сейчас") { GRow("Состояние", if (p.saver) "Экономия включена" else "Обычный режим", icon = Icons.Rounded.Eco) }
    }
}

@Composable
fun PerfTab() {
    val p = LocalPrefs.current
    Page("Производительность") {
        GGroup(note = "«Эконом» выключает размытие панелей. Скорость анимаций — в разделе «Анимации».") {
            Chips("Профиль", listOf("Баланс", "Качество", "Эконом"), p.perf) { p.perf = it }
        }
        GGroup("Эффекты") {
            Toggle("Размытие под панелями", "Самый затратный эффект (Android 12+)", p.blurPanels) { p.blurPanels = it }
            Toggle("Параллакс обоев", null, p.parallax) { p.parallax = it }
        }
    }
}

@Composable
fun AboutTab() {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val role = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        u?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(p.export().toByteArray()) }; Toast.makeText(ctx, "Копия сохранена", Toast.LENGTH_SHORT).show() } }
    val load = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u?.let { try { p.import(ctx.contentResolver.openInputStream(it)!!.bufferedReader().readText()); Toast.makeText(ctx, "Настройки восстановлены", Toast.LENGTH_SHORT).show() }
            catch (e: Exception) { Toast.makeText(ctx, "Неверный файл", Toast.LENGTH_SHORT).show() } } }
    Page("О лаунчере") {
        GGroup { GRow("Liquid Glass Launcher", "Версия 1.2", icon = Icons.Rounded.AutoAwesome) }
        GButton("Сделать лаунчером по умолчанию", primary = true) {
            if (android.os.Build.VERSION.SDK_INT >= 29) role.launch(ctx.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_HOME))
            else ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }
        GGroup("Данные") {
            GRow("Резервная копия", "Сохранить настройки в файл", { save.launch("liquid-glass-backup.json") }, Icons.Rounded.Backup) { Chevron() }
            GRow("Восстановить настройки", "Загрузить из файла", { load.launch(arrayOf("application/json", "*/*")) }, Icons.Rounded.Restore) { Chevron() }
            GRow("Сбросить лаунчер", "Настройки, раскладка и фото-виджеты", { confirm = true }, Icons.Rounded.RestartAlt, Color(0xFFEF4444)) { Chevron() }
        }
    }
    if (confirm) ConfirmDialog("Сбросить лаунчер?", "Все настройки, раскладка и фото-виджеты будут удалены.", "Сбросить",
        { val h = AppWidgetHost(ctx, 1024); p.hosted.forEach { h.deleteAppWidgetId(it.id) }; p.reset() }) { confirm = false }
}

/** Две строки для группы «Приложения»: автопапки и расформирование (с подтверждением). */
@Composable
fun FolderRows() {
    val p = LocalPrefs.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var confirm by remember { mutableStateOf(false) }
    GRow("Разложить по папкам", "Игры, Google, соцсети и другое", {
        scope.launch {
            val m = HomeModel(p); m.refresh(ctx.applicationContext); val n = m.autoFolders()
            Toast.makeText(ctx, if (n > 0) "Создано папок: $n" else "Нечего группировать", Toast.LENGTH_SHORT).show()
        }
    }, Icons.Rounded.CreateNewFolder) { Chevron() }
    GRow("Расформировать все папки", "Приложения вернутся на рабочий стол", { confirm = true }, Icons.Rounded.FolderOff) { Chevron() }
    if (confirm) ConfirmDialog("Расформировать папки?", "Все папки будут удалены, приложения останутся на рабочем столе.", "Расформировать", {
        scope.launch { val m = HomeModel(p); m.refresh(ctx.applicationContext); m.dissolveAll(); Toast.makeText(ctx, "Папки расформированы", Toast.LENGTH_SHORT).show() }
    }) { confirm = false }
}

@Composable
fun SystemScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var canWrite by remember { mutableStateOf(Settings.System.canWrite(ctx)) }
    val grant = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { canWrite = Settings.System.canWrite(ctx) }
    fun open(a: String) { try { ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, "Недоступно на этом устройстве", Toast.LENGTH_SHORT).show() } }
    Page("Системные настройки", back) {
        GGroup("Быстрое управление") {
            SliderRow("Громкость мультимедиа", vol, 0f..maxV.toFloat(), { "${it.toInt()}/$maxV" }, maxOf(0, maxV - 1)) {
                vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) }
            if (canWrite) {
                var br by remember { mutableFloatStateOf(try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS).toFloat() } catch (e: Exception) { 128f }) }
                SliderRow("Яркость экрана", br, 1f..255f, { "${(it / 2.55f).toInt()}%" }) {
                    br = it
                    try {
                        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, it.toInt())
                    } catch (e: Exception) {}
                }
            } else GRow("Яркость экрана", "Нажмите, чтобы разрешить изменение системных настроек", {
                grant.launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName))) }, Icons.Rounded.Lock) { Chevron() }
        }
        GGroup("Открыть настройки Android") {
            listOf(
                Triple("Wi-Fi", "Сети и подключение", Settings.ACTION_WIFI_SETTINGS) to Icons.Rounded.Wifi,
                Triple("Bluetooth", "Устройства", Settings.ACTION_BLUETOOTH_SETTINGS) to Icons.Rounded.Bluetooth,
                Triple("Мобильная сеть", "SIM и передача данных", Settings.ACTION_DATA_ROAMING_SETTINGS) to Icons.Rounded.SignalCellularAlt,
                Triple("Режим полёта", "Беспроводные сети", Settings.ACTION_AIRPLANE_MODE_SETTINGS) to Icons.Rounded.AirplanemodeActive,
                Triple("Экран", "Яркость, тёмная тема, тайм-аут", Settings.ACTION_DISPLAY_SETTINGS) to Icons.Rounded.Smartphone,
                Triple("Звук и вибрация", "Громкость, рингтоны", Settings.ACTION_SOUND_SETTINGS) to Icons.Rounded.VolumeUp,
                Triple("Батарея", "Режим энергосбережения Android", Settings.ACTION_BATTERY_SAVER_SETTINGS) to Icons.Rounded.BatteryFull,
                Triple("Приложения", "Управление приложениями", Settings.ACTION_APPLICATION_SETTINGS) to Icons.Rounded.Apps,
                Triple("Память", "Хранилище", Settings.ACTION_INTERNAL_STORAGE_SETTINGS) to Icons.Rounded.Storage,
                Triple("Геолокация", "Службы определения места", Settings.ACTION_LOCATION_SOURCE_SETTINGS) to Icons.Rounded.LocationOn,
                Triple("Приложения по умолчанию", "Браузер, звонки, лаунчер", Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS) to Icons.Rounded.CheckCircle,
                Triple("Специальные возможности", "Службы и жесты", Settings.ACTION_ACCESSIBILITY_SETTINGS) to Icons.Rounded.Accessibility,
                Triple("Язык", "Язык системы", Settings.ACTION_LOCALE_SETTINGS) to Icons.Rounded.Language,
                Triple("Дата и время", "Часовой пояс", Settings.ACTION_DATE_SETTINGS) to Icons.Rounded.Schedule,
                Triple("Все настройки Android", "Главное меню настроек", Settings.ACTION_SETTINGS) to Icons.Rounded.Settings
            ).forEach { (t, ic) -> GRow(t.first, t.second, { open(t.third) }, ic) { Chevron() } }
        }
    }
}

@Composable
fun WidgetsScreen(back: () -> Unit) {
    val p = LocalPrefs.current; val ctx = LocalContext.current
    val awm = remember { android.appwidget.AppWidgetManager.getInstance(ctx) }
    var deleting by remember { mutableStateOf<HostedWidget?>(null) }
    Page("Виджеты Android", back) {
        if (p.hosted.isEmpty()) GNote("Виджетов нет. На главном экране долгое нажатие на пустом месте → «Добавить виджет Android».")
        p.hosted.forEach { w ->
            val info = awm.getAppWidgetInfo(w.id)
            GGroup(info?.loadLabel(ctx.packageManager) ?: "Виджет удалён") {
                SliderRow("Высота", w.h.toFloat(), 80f..420f, { "${it.toInt()} dp" }) { v -> p.hosted = p.hosted.map { if (it.id == w.id) it.copy(h = v.toInt()) else it } }
                GRow("Удалить виджет", null, { deleting = w }, Icons.Rounded.Delete, Color(0xFFEF4444)) { Chevron() }
            }
        }
    }
    deleting?.let { w -> ConfirmDialog("Удалить виджет?", "Он пропадёт с рабочего стола.", "Удалить",
        { AppWidgetHost(ctx, 1024).deleteAppWidgetId(w.id); p.hosted = p.hosted - w }) { deleting = null } }
}
