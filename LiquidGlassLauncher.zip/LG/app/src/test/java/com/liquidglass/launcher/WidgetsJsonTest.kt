package com.liquidglass.launcher

import org.junit.Assert.assertEquals
import org.junit.Test

class WidgetsJsonTest {
    @Test fun photoWidgetsRoundTrip() {
        val src = listOf(PhotoWidget("a", listOf("content://x/1", "content://x/2"), 2, 18, 0.8f, false, 12))
        assertEquals(src, parseWidgets(src.toJson()))
    }
    @Test fun hostedWidgetsRoundTrip() {
        val src = listOf(HostedWidget(7, 160), HostedWidget(9, 220))
        assertEquals(src, parseHosted(src.toJson()))
    }
    @Test fun brokenJsonGivesEmptyList() {
        assertEquals(emptyList<PhotoWidget>(), parseWidgets("not json"))
        assertEquals(emptyList<HostedWidget>(), parseHosted(""))
    }
}
