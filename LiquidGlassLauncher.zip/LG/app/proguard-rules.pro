# Лаунчер использует рефлексию только для системного StatusBarManager (системный класс, не обфусцируется).
-keep class com.liquidglass.launcher.LockService { *; }
-keep class com.liquidglass.launcher.NotifService { *; }
