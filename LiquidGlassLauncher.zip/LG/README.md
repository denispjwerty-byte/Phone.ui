# Liquid Glass Launcher
Откройте папку в Android Studio (Ladybug+), дождитесь Gradle Sync, запустите на устройстве/эмуляторе (Android 8.0+, размытие — Android 12+).
Нажмите «Домой» → выберите Liquid Glass Launcher → «Всегда». Настройки — иконка «Настройки лаунчера» или долгое нажатие на пустом месте.
